/* ═══════════════════════════════════════════════════════════════════════
   ARROW PLAYGROUND — FRONTEND
   Talks to the Spring Boot backend: /api/compile, /api/run, /api/ai-generate
   ═══════════════════════════════════════════════════════════════════════ */

const editor = document.getElementById('editor');
const highlightEl = document.getElementById('highlight');
const lineNums = document.getElementById('lineNums');

/* ── Theme (dark / light, persisted) ─────────────────────────────────── */
function initTheme() {
  const saved = localStorage.getItem('arrow-theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeIcon(saved);
}
function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme') || 'dark';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('arrow-theme', next);
  updateThemeIcon(next);
}
function updateThemeIcon(theme) {
  const icon = document.getElementById('themeIcon');
  if (theme === 'light') {
    icon.innerHTML = '<path d="M8 1.5a6.5 6.5 0 108.4 8.4A7 7 0 018 1.5z"/>';
  } else {
    icon.innerHTML = '<circle cx="8" cy="8" r="3.5"/><path d="M8 1v1.5M8 13.5V15M2.6 2.6l1 1M12.4 12.4l1 1M1 8h1.5M13.5 8H15M2.6 13.4l1-1M12.4 3.6l1-1"/>';
  }
}
document.getElementById('themeToggle').addEventListener('click', toggleTheme);

/* ── Editor: highlighting + line numbers ─────────────────────────────── */
let errorLines = new Set();

function updateEditor() {
  const val = editor.value;
  highlightEl.innerHTML = highlight(val) + '\n';
  const count = val.split('\n').length;
  const numsHtml = Array.from({length: count}, (_, i) => {
    const ln = i + 1;
    return errorLines.has(ln) ? `<span class="err-line">${ln}</span>` : String(ln);
  }).join('\n');
  lineNums.innerHTML = numsHtml;
  highlightEl.scrollTop = editor.scrollTop;
  highlightEl.scrollLeft = editor.scrollLeft;
  document.getElementById('editorInfo').textContent = count + ' lines';
}

editor.addEventListener('input', () => { updateEditor(); scheduleLiveCheck(); });
editor.addEventListener('scroll', () => {
  highlightEl.scrollTop = editor.scrollTop;
  highlightEl.scrollLeft = editor.scrollLeft;
  lineNums.scrollTop = editor.scrollTop;
});
editor.addEventListener('keydown', e => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const s = editor.selectionStart, end = editor.selectionEnd;
    editor.value = editor.value.slice(0, s) + '  ' + editor.value.slice(end);
    editor.selectionStart = editor.selectionEnd = s + 2;
    updateEditor();
  }
  requestAnimationFrame(updateCursor);
});
editor.addEventListener('click', updateCursor);
editor.addEventListener('keyup', updateCursor);

function updateCursor() {
  const s = editor.selectionStart, val = editor.value.slice(0, s);
  const lines = val.split('\n');
  document.getElementById('cursorPos').textContent = `Ln ${lines.length}, Col ${lines[lines.length - 1].length + 1}`;
}

function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

/* Client-side syntax highlighter for the Arrow source (fast, no round-trip) */
function highlight(code) {
  const lines = code.split('\n');
  let inBlock = false;
  const out = lines.map(rawLine => {
    let line = rawLine;
    if (inBlock) {
      if (line.includes('*/')) { inBlock = false; return `<span class="hl-comment">${esc(rawLine)}</span>`; }
      return `<span class="hl-comment">${esc(rawLine)}</span>`;
    }
    if (line.includes('/*') && !line.includes('*/')) { inBlock = true; return `<span class="hl-comment">${esc(rawLine)}</span>`; }

    const lcIdx = line.indexOf('//');
    let comment = '', codepart = line;
    if (lcIdx >= 0) { codepart = line.slice(0, lcIdx); comment = `<span class="hl-comment">${esc(line.slice(lcIdx))}</span>`; }

    let result = '', i = 0;
    const s = codepart;
    while (i < s.length) {
      if (s[i] === '"') {
        let j = i + 1; while (j < s.length && s[j] !== '"') { if (s[j] === '\\') j++; j++; }
        result += `<span class="hl-str">${esc(s.slice(i, j + 1))}</span>`; i = j + 1; continue;
      }
      if (s[i] === "'") {
        let j = i + 1; if (s[j] === '\\') j++; j++; if (s[j] === "'") j++;
        result += `<span class="hl-str">${esc(s.slice(i, j))}</span>`; i = j; continue;
      }
      if (/[0-9]/.test(s[i])) {
        let j = i; while (j < s.length && /[0-9.eE+\-]/.test(s[j])) j++;
        result += `<span class="hl-lit">${esc(s.slice(i, j))}</span>`; i = j; continue;
      }
      if (/[a-zA-Z_]/.test(s[i])) {
        let j = i; while (j < s.length && /[a-zA-Z_0-9]/.test(s[j])) j++;
        const w = s.slice(i, j);
        const types = ['int', 'float', 'double', 'char', 'string', 'bool', 'void', 'self', 'super'];
        if (types.includes(w)) result += `<span class="hl-type">${esc(w)}</span>`;
        else result += `<span class="hl-id">${esc(w)}</span>`;
        i = j; continue;
      }
      const c = s[i];
      if ('→←↑↓↔'.includes(c)) { result += `<span class="hl-arrow">${esc(c)}</span>`; i++; continue; }
      if ('∴∵'.includes(c)) { result += `<span class="hl-io">${esc(c)}</span>`; i++; continue; }
      if ('⟲↯↷?!'.includes(c)) { result += `<span class="hl-flow">${esc(c)}</span>`; i++; continue; }
      if ('ƒ◈◎◆★△✦@#'.includes(c)) { result += `<span class="hl-oop">${esc(c)}</span>`; i++; continue; }
      if ('✓✗∅'.includes(c)) { result += `<span class="hl-bool">${esc(c)}</span>`; i++; continue; }
      if ('+-*/%&|=<>~'.includes(c)) { result += `<span class="hl-op">${esc(c)}</span>`; i++; continue; }
      result += esc(c); i++;
    }
    return result + comment;
  });
  return out.join('\n');
}

function highlightJava(code) {
  if (!code) return '';
  const keywords = ['public', 'static', 'void', 'class', 'interface', 'abstract', 'extends', 'if', 'else', 'while', 'switch', 'case', 'default', 'break', 'continue', 'return', 'new', 'this', 'super', 'import'];
  const types = ['int', 'float', 'double', 'char', 'boolean', 'String', 'Scanner', 'Integer', 'Float', 'Double', 'Boolean'];
  let h = esc(code);
  h = h.replace(/(\/\/.*)/g, '<span class="j-cmt">$1</span>');
  h = h.replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="j-cmt">$1</span>');
  h = h.replace(/(&quot;(?:[^&]|&(?!quot;))*?&quot;)/g, '<span class="j-str">$1</span>');
  h = h.replace(/\b(\d+\.?\d*(?:f|d|L)?)\b/g, '<span class="j-num">$1</span>');
  types.forEach(t => { h = h.replace(new RegExp(`\\b(${t})\\b`, 'g'), '<span class="j-type">$1</span>'); });
  keywords.forEach(k => { h = h.replace(new RegExp(`\\b(${k})\\b`, 'g'), '<span class="j-kw">$1</span>'); });
  return h;
}

/* ── Examples ─────────────────────────────────────────────────────────── */
const EXAMPLES = {
  hello: `// Hello World in Arrow
string name → "World"
∴ "Hello, " + name + "!"
∴ "Welcome to Arrow → where symbols speak louder than words."`,

  factorial: `// Factorial using recursion
ƒ int factorial(int n) :
  ? (n <= 1) :
    ← 1
  ;
  ← n * factorial(n - 1)
;

int result → factorial(10)
∴ "10! = " + result`,

  fizzbuzz: `// FizzBuzz 1-20
int i → 1
⟲ (i <= 20) :
  ? (i % 15 == 0) : ∴ "FizzBuzz" ;
  ?? (i % 3 == 0) : ∴ "Fizz" ;
  ?? (i % 5 == 0) : ∴ "Buzz" ;
  ! : ∴ i ;
  i↑
;`,

  class: `// Object-Oriented programming in Arrow
◈ Animal :
  string name
  int age

  ƒ void speak() :
    ∴ name + " says: ..."
  ;

  ƒ string describe() :
    ← name + " (age " + age + ")"
  ;
;

◈ Dog △ Animal :
  ★ ƒ void speak() :
    ∴ name + " says: Woof!"
  ;
;

Animal a → ✦ Dog()
a.name → "Rex"
a.age → 3
a.speak()
∴ a.describe()`,

  switch: `// Switch statement example
int day → 3

@(day) :
  # 1 :
    ∴ "Monday"
  ;
  # 2 :
    ∴ "Tuesday"
  ;
  # 3 :
    ∴ "Wednesday"
  ;
  # 4 :
    ∴ "Thursday"
  ;
  # 5 :
    ∴ "Friday"
  ;
  * :
    ∴ "Weekend!"
  ;
;`,

  fibonacci: `// Fibonacci sequence
ƒ int fib(int n) :
  ? (n <= 1) :
    ← n
  ;
  ← fib(n - 1) + fib(n - 2)
;

int i → 0
⟲ (i < 12) :
  ∴ fib(i)
  i↑
;`,

  evens: `// Print even numbers from 2 to 30
int n → 2
⟲ (n <= 30) :
  ∴ n
  n → n + 2
;`
};

function loadExample(key) {
  editor.value = EXAMPLES[key] || '';
  updateEditor();
  setStatus('', '');
  scheduleLiveCheck();
}

function clearEditor() { editor.value = ''; updateEditor(); setStatus('', ''); errorLines = new Set(); renderErrorsPanel([]); }
function copyCode() { navigator.clipboard.writeText(editor.value).catch(() => {}); }

/* ── Tabs ─────────────────────────────────────────────────────────────── */
function switchTab(name) {
  document.querySelectorAll('.tab').forEach(el => el.classList.toggle('active', el.dataset.tab === name));
  document.querySelectorAll('.tab-panel').forEach(el => el.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
}
function showAI() { switchTab('ai'); }

/* ── Status bar ───────────────────────────────────────────────────────── */
function setStatus(msg, state) {
  const dot = document.getElementById('statusDot');
  const txt = document.getElementById('statusText');
  dot.className = 'status-dot' + (state === 'ok' ? ' ok' : state === 'err' ? ' err' : state === 'busy' ? ' busy' : '');
  txt.textContent = msg || 'Ready';
}

/* ── Backend calls ────────────────────────────────────────────────────── */
async function apiCompile(source) {
  const r = await fetch('/api/compile', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ source })
  });
  return r.json();
}
async function apiRun(source) {
  const r = await fetch('/api/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ source })
  });
  return r.json();
}
async function apiAiGenerate(prompt) {
  const r = await fetch('/api/ai-generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt })
  });
  return r.json();
}

/* ── Live error checking (debounced) ─────────────────────────────────── */
let liveCheckTimer = null;
function scheduleLiveCheck() {
  clearTimeout(liveCheckTimer);
  liveCheckTimer = setTimeout(runLiveCheck, 500);
}
async function runLiveCheck() {
  const source = editor.value;
  if (!source.trim()) {
    errorLines = new Set();
    updateEditor();
    renderErrorsPanel([]);
    document.getElementById('errorCount').textContent = '';
    return;
  }
  try {
    const r = await apiCompile(source);
    errorLines = new Set(r.diagnostics.filter(d => d.level === 'error').map(d => d.line));
    updateEditor();
    renderErrorsPanel(r.diagnostics);
    updateErrorBadge(r.errorCount, r.warningCount);
    if (r.javaCode) document.getElementById('javaOut').innerHTML = highlightJava(r.javaCode);
    window._lastAstText = r.astText;
  } catch (e) {
    // network hiccup during live check — ignore silently
  }
}

function updateErrorBadge(errCount, warnCount) {
  const ecEl = document.getElementById('errorCount');
  ecEl.textContent = errCount > 0 ? `(${errCount})` : warnCount > 0 ? `(${warnCount})` : '';
  ecEl.style.color = errCount > 0 ? 'var(--red)' : warnCount > 0 ? 'var(--yellow)' : '';
}

function renderErrorsPanel(diagnostics) {
  const panel = document.getElementById('errorsPanel');
  if (!diagnostics || diagnostics.length === 0) {
    panel.innerHTML = `<div class="no-errors">
      <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="16" cy="16" r="14"/><path d="M10 16l4 4 8-8"/></svg>
      No errors — looking good
    </div>`;
    return;
  }
  panel.innerHTML = diagnostics.map(d => {
    const isWarn = d.level === 'warning';
    const loc = d.line > 0 ? `${d.phase}  ·  line ${d.line}, col ${d.col}` : `${d.phase}`;
    let snippet = '';
    if (d.sourceLine) {
      const caret = ' '.repeat(Math.max(0, d.col - 1)) + '^';
      snippet = `<div class="error-snippet">${esc(d.sourceLine)}\n<span class="error-caret">${esc(caret)}</span></div>`;
    }
    return `<div class="error-card${isWarn ? ' warning' : ''}" onclick="jumpToLine(${d.line})">
      <div class="error-loc">${esc(loc)}</div>
      <div class="error-msg">${esc(d.message)}</div>
      ${d.hint ? `<div class="error-hint">hint: ${esc(d.hint)}</div>` : ''}
      ${snippet}
    </div>`;
  }).join('');
}

function jumpToLine(line) {
  if (!line || line < 1) return;
  const lines = editor.value.split('\n');
  let pos = 0;
  for (let i = 0; i < line - 1 && i < lines.length; i++) pos += lines[i].length + 1;
  editor.focus();
  editor.setSelectionRange(pos, pos + (lines[line - 1] ? lines[line - 1].length : 0));
  updateCursor();
}

/* ── Run ──────────────────────────────────────────────────────────────── */
async function runCompiler() {
  const source = editor.value.trim();
  if (!source) { setStatus('No source code', ''); return; }

  setStatus('Compiling…', 'busy');
  document.getElementById('runBtn').disabled = true;

  try {
    const r = await apiRun(source);

    errorLines = new Set((r.diagnostics || []).filter(d => d.level === 'error').map(d => d.line));
    updateEditor();
    renderErrorsPanel(r.diagnostics);
    updateErrorBadge(r.errorCount, r.warningCount);

    // Also refresh the Java tab
    const compileResp = await apiCompile(source);
    if (compileResp.javaCode) {
      document.getElementById('javaOut').innerHTML = highlightJava(compileResp.javaCode);
    } else {
      document.getElementById('javaOut').textContent = '// Compilation failed — see Errors tab.';
    }
    window._lastAstText = compileResp.astText;

    const programOut = document.getElementById('programOut');
    if (r.errorCount > 0) {
      programOut.innerHTML = `<span class="stderr">Compilation failed with ${r.errorCount} error(s).\nSee the Errors tab for details.</span>`;
      switchTab('errors');
    } else {
      let html = '';
      if (r.output) html += `<span class="stdout">${esc(r.output)}</span>`;
      if (r.runtimeError) html += `\n<span class="stderr">[Runtime] ${esc(r.runtimeError)}</span>`;
      if (!html) html = '<span class="note">// Program ran with no output.</span>';
      programOut.innerHTML = html;
      switchTab('output');
    }

    if (r.errorCount > 0) setStatus(`${r.errorCount} error${r.errorCount === 1 ? '' : 's'}`, 'err');
    else if (r.warningCount > 0) setStatus(`OK with ${r.warningCount} warning${r.warningCount === 1 ? '' : 's'}`, 'ok');
    else setStatus('Compiled successfully', 'ok');

  } catch (e) {
    setStatus('Network error contacting backend', 'err');
  }

  document.getElementById('runBtn').disabled = false;
}

/* ── AST modal ────────────────────────────────────────────────────────── */
const astModalOverlay = document.getElementById('astModalOverlay');
document.getElementById('astBtn').addEventListener('click', async () => {
  const astContent = document.getElementById('astTreeContent');
  astContent.textContent = 'Compiling…';
  astModalOverlay.classList.add('open');
  try {
    const r = await apiCompile(editor.value);
    astContent.textContent = r.astText || (r.errorCount > 0
      ? 'Could not build a full AST — fix parse errors first (see Errors tab).'
      : '// No AST available.');
  } catch (e) {
    astContent.textContent = 'Network error contacting backend.';
  }
});
document.getElementById('astModalClose').addEventListener('click', () => astModalOverlay.classList.remove('open'));
astModalOverlay.addEventListener('click', (e) => { if (e.target === astModalOverlay) astModalOverlay.classList.remove('open'); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') astModalOverlay.classList.remove('open'); });

/* ── AI Generate ──────────────────────────────────────────────────────── */
async function generateAI() {
  const prompt = document.getElementById('aiPrompt').value.trim();
  if (!prompt) return;

  const aiResult = document.getElementById('aiResult');
  const aiBtn = document.getElementById('aiBtn');
  const useBtn = document.getElementById('useAIBtn');
  const retryBtn = document.getElementById('retryBtn');
  const statusLine = document.getElementById('aiStatusLine');

  aiResult.textContent = '// Generating Arrow code...';
  aiResult.className = 'ai-result loading';
  aiBtn.disabled = true;
  useBtn.style.display = 'none';
  retryBtn.style.display = 'none';
  statusLine.textContent = 'Contacting AI model…';

  try {
    const r = await apiAiGenerate(prompt);
    aiResult.textContent = r.code || '// (no code returned)';
    aiResult.className = 'ai-result';
    statusLine.textContent = r.message || '';
    if (r.code) {
      useBtn.style.display = '';
      retryBtn.style.display = '';
      window._lastAICode = r.code;
    }
  } catch (e) {
    aiResult.textContent = `// Error: ${e.message}`;
    aiResult.className = 'ai-result';
    statusLine.textContent = '';
  }

  aiBtn.disabled = false;
}

function useAICode() {
  if (!window._lastAICode) return;
  editor.value = window._lastAICode;
  updateEditor();
  switchTab('java');
  setTimeout(runCompiler, 50);
}

/* ── Init ─────────────────────────────────────────────────────────────── */
initTheme();
loadExample('class');
updateCursor();
scheduleLiveCheck();
