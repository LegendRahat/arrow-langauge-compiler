package com.arrow.diagnostic;

/**
 * A single compiler diagnostic (error or warning) with precise source location
 * and an actionable message. Modelled after the diagnostic style of rustc/clang.
 */
public final class Diagnostic {

    public enum Level { ERROR, WARNING, NOTE }

    public final Level   level;
    public final int     line;      // 1-based
    public final int     col;       // 1-based
    public final String  phase;     // "Lexer" | "Parser" | "Semantic" | "CodeGen"
    public final String  message;
    public final String  hint;      // nullable
    public final String  sourceLine; // nullable

    public Diagnostic(Level level, int line, int col,
                      String phase, String message,
                      String hint, String sourceLine) {
        this.level      = level;
        this.line       = line;
        this.col        = col;
        this.phase      = phase;
        this.message    = message;
        this.hint       = hint;
        this.sourceLine = sourceLine;
    }

    public static Diagnostic error(int line, int col, String phase,
                                   String message, String hint, String src) {
        return new Diagnostic(Level.ERROR, line, col, phase, message, hint, src);
    }

    public static Diagnostic warning(int line, int col, String phase,
                                     String message, String hint, String src) {
        return new Diagnostic(Level.WARNING, line, col, phase, message, hint, src);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String tag = level == Level.ERROR ? "error" :
                     level == Level.WARNING ? "warning" : "note";
        sb.append(tag).append("[").append(phase).append("]: ").append(message).append("\n");
        sb.append(" --> line ").append(line).append(", col ").append(col).append("\n");

        if (sourceLine != null && !sourceLine.isEmpty()) {
            String lineNum = String.valueOf(line);
            String pad     = " ".repeat(lineNum.length());
            sb.append(pad).append(" |\n");
            sb.append(lineNum).append(" | ").append(sourceLine).append("\n");
            int caretCol = Math.max(0, col - 1);
            sb.append(pad).append(" | ").append(" ".repeat(caretCol)).append("^\n");
        }
        if (hint != null && !hint.isEmpty()) {
            sb.append("   = hint: ").append(hint).append("\n");
        }
        return sb.toString();
    }
}
