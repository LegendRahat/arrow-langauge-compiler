package com.arrow.diagnostic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Accumulates diagnostics from every compiler phase.
 * Phases add to the bag and continue; only the caller decides when to stop.
 */
public final class DiagnosticBag {

    private final List<Diagnostic> items = new ArrayList<>();
    private final String[]         sourceLines;

    public DiagnosticBag(String source) {
        this.sourceLines = (source != null ? source : "").split("\n", -1);
    }

    public void error(int line, int col, String phase, String message, String hint) {
        items.add(Diagnostic.error(line, col, phase, message, hint, lineText(line)));
    }

    public void warning(int line, int col, String phase, String message, String hint) {
        items.add(Diagnostic.warning(line, col, phase, message, hint, lineText(line)));
    }

    public void error(int line, int col, String phase, String message, String hint, String sourceLine) {
        String src = sourceLine != null ? sourceLine : lineText(line);
        items.add(Diagnostic.error(line, col, phase, message, hint, src));
    }

    public void warning(int line, int col, String phase, String message, String hint, String sourceLine) {
        String src = sourceLine != null ? sourceLine : lineText(line);
        items.add(Diagnostic.warning(line, col, phase, message, hint, src));
    }

    public boolean hasErrors() {
        return items.stream().anyMatch(d -> d.level == Diagnostic.Level.ERROR);
    }

    public int errorCount() {
        return (int) items.stream().filter(d -> d.level == Diagnostic.Level.ERROR).count();
    }

    public int warningCount() {
        return (int) items.stream().filter(d -> d.level == Diagnostic.Level.WARNING).count();
    }

    public List<Diagnostic> all() {
        return Collections.unmodifiableList(items);
    }

    public List<Diagnostic> sorted() {
        List<Diagnostic> copy = new ArrayList<>(items);
        copy.sort((a, b) -> a.line != b.line ? Integer.compare(a.line, b.line)
                                              : Integer.compare(a.col,  b.col));
        return Collections.unmodifiableList(copy);
    }

    public String render() {
        if (items.isEmpty()) return "Compilation successful — no diagnostics.\n";
        StringBuilder sb = new StringBuilder();
        for (Diagnostic d : sorted()) sb.append(d.toString()).append("\n");
        int errs  = errorCount();
        int warns = warningCount();
        sb.append("-".repeat(50)).append("\n");
        if (errs  > 0) sb.append("  ").append(errs ).append(" error(s)\n");
        if (warns > 0) sb.append("  ").append(warns).append(" warning(s)\n");
        return sb.toString();
    }

    private String lineText(int line) {
        if (line < 1 || line > sourceLines.length) return "";
        return sourceLines[line - 1];
    }
}
