package com.arrow.parser;

import com.arrow.diagnostic.DiagnosticBag;
import com.arrow.lexer.Token;
import com.arrow.lexer.TokenType;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Arrow language parser — production-grade implementation with panic-mode recovery.
 *
 * Recovery strategy (phrase-level / panic-mode hybrid):
 *  - parseStatement() is the sole place that catches ParseError at statement
 *    granularity. It always recovers internally and returns null on failure.
 *  - synchronize(fences...) skips tokens until a known "safe" boundary is found.
 *
 * Hardening:
 *  1. super.method(args) as a statement works.
 *  2. parseReturn() guards against EOF.
 *  3. abstract interface handled.
 *  4. Recovery boundaries are explicit and singular.
 *  5. Null nodes returned from recovery are filtered at block level.
 *  6. All expect() calls use typed ParseError.
 *  7. Column numbers flow through from Token into diagnostics.
 *  8. Expression / statement recursion depth is bounded to avoid StackOverflowError.
 *  9. Numeric literal parsing is defensively wrapped.
 */
public final class Parser {

    private static final class ParseError extends RuntimeException {
        ParseError(String msg) { super(msg, null, true, false); }
    }

    private static final int MAX_EXPR_DEPTH = 500;
    private static final int MAX_STMT_DEPTH = 300;

    private static final Set<TokenType> STMT_START = EnumSet.of(
        TokenType.TYPE_INT, TokenType.TYPE_FLOAT, TokenType.TYPE_DOUBLE,
        TokenType.TYPE_CHAR, TokenType.TYPE_STRING, TokenType.TYPE_BOOL,
        TokenType.TYPE_VOID,
        TokenType.IDENTIFIER,
        TokenType.FUNCTION, TokenType.CLASS, TokenType.INTERFACE,
        TokenType.ABSTRACT, TokenType.OVERRIDE,
        TokenType.IF, TokenType.LOOP, TokenType.SWITCH,
        TokenType.BREAK, TokenType.CONTINUE, TokenType.RETURN_OP,
        TokenType.PRINT, TokenType.INPUT, TokenType.SWAP,
        TokenType.SELF, TokenType.SUPER,
        TokenType.BLOCK_END, TokenType.EOF
    );

    private final List<Token>    toks;
    private       int            pos = 0;
    private final DiagnosticBag  diag;
    private       int            exprDepth = 0;
    private       int            stmtDepth = 0;

    public Parser(List<Token> toks, DiagnosticBag diag) {
        this.toks = (toks != null) ? toks : List.of(new Token(TokenType.EOF, "EOF", 1, 1));
        this.diag = diag;
    }

    private Token cur()        { return toks.get(pos); }
    private Token peek(int o)  { int i = pos + o; return i < toks.size() ? toks.get(i) : toks.get(toks.size()-1); }
    private Token advance()    { Token t = toks.get(pos); if (pos < toks.size()-1) pos++; return t; }
    private boolean check(TokenType t)  { return cur().type == t; }
    private boolean match(TokenType t)  { if (check(t)) { advance(); return true; } return false; }

    private Token expect(TokenType t) {
        if (!check(t)) {
            Token bad = cur();
            String hint = hintForMissing(t, bad);
            diag.error(bad.line, bad.col, "Parser",
                       "expected " + humanName(t) + " but found '" + bad.value + "' (" + bad.type + ")",
                       hint, null);
            throw new ParseError("expected " + t);
        }
        return advance();
    }

    private void expectOrWarn(TokenType t) {
        if (!check(t)) {
            Token bad = cur();
            diag.error(bad.line, bad.col, "Parser",
                       "expected " + humanName(t) + " to close block, found '" + bad.value + "'",
                       "add '" + tokenChar(t) + "' here", null);
        } else {
            advance();
        }
    }

    private void synchronize(TokenType... fences) {
        Set<TokenType> fenceSet = EnumSet.copyOf(STMT_START);
        for (TokenType f : fences) fenceSet.add(f);
        while (!check(TokenType.EOF)) {
            if (fenceSet.contains(cur().type)) return;
            advance();
        }
    }

    private boolean isTypeKeyword() {
        switch (cur().type) {
            case TYPE_INT: case TYPE_FLOAT: case TYPE_DOUBLE:
            case TYPE_CHAR: case TYPE_STRING: case TYPE_BOOL: case TYPE_VOID:
                return true;
            default: return false;
        }
    }

    private String typeName(Token t) {
        switch (t.type) {
            case TYPE_INT:    return "int";
            case TYPE_FLOAT:  return "float";
            case TYPE_DOUBLE: return "double";
            case TYPE_CHAR:   return "char";
            case TYPE_STRING: return "string";
            case TYPE_BOOL:   return "bool";
            case TYPE_VOID:   return "void";
            default:          return t.value;
        }
    }

    public ASTNode.Program parse() {
        List<ASTNode> stmts = new ArrayList<>();
        while (!check(TokenType.EOF)) {
            int before = pos;
            ASTNode s = parseStatement();
            if (s != null) stmts.add(s);
            if (pos == before) {
                Token stuck = cur();
                diag.error(stuck.line, stuck.col, "Parser",
                           "unexpected token '" + stuck.value + "' — cannot start a statement",
                           null, null);
                advance();
            }
        }
        return new ASTNode.Program(stmts);
    }

    private ASTNode.Block parseBlock() {
        stmtDepth++;
        try {
            if (stmtDepth > MAX_STMT_DEPTH) {
                Token here = cur();
                diag.error(here.line, here.col, "Parser",
                           "block nested too deeply (limit " + MAX_STMT_DEPTH + ")",
                           "simplify this code — extremely deep nesting is not supported", null);
                throw new ParseError("block too deep");
            }
            return parseBlockBody();
        } finally {
            stmtDepth--;
        }
    }

    private ASTNode.Block parseBlockBody() {
        int l = cur().line;
        expect(TokenType.BLOCK_START);

        List<ASTNode> stmts = new ArrayList<>();
        while (!check(TokenType.BLOCK_END) && !check(TokenType.EOF)) {
            int before = pos;
            ASTNode s = parseStatement();
            if (s != null) stmts.add(s);
            if (pos == before) {
                Token stuck = cur();
                diag.error(stuck.line, stuck.col, "Parser",
                           "unexpected token '" + stuck.value + "' inside block", null, null);
                advance();
            }
        }
        expectOrWarn(TokenType.BLOCK_END);
        return new ASTNode.Block(stmts, l);
    }

    private ASTNode parseStatement() {
        try {
            switch (cur().type) {
                case ABSTRACT: {
                    TokenType next = peek(1).type;
                    if (next == TokenType.CLASS || next == TokenType.INTERFACE)
                        return parseClass();
                    return parseClassMember();
                }
                case CLASS:     return parseClass();
                case INTERFACE: return parseInterface();
                case FUNCTION:  return parseFunc(false, false);
                case OVERRIDE:  return parseClassMember();
                case IF:        return parseIf();
                case LOOP:      return parseLoop();
                case SWITCH:    return parseSwitch();
                case BREAK: {
                    int l = advance().line;
                    return new ASTNode.Break(l);
                }
                case CONTINUE: {
                    int l = advance().line;
                    return new ASTNode.Continue(l);
                }
                case RETURN_OP: return parseReturn();
                case PRINT:     return parsePrint();
                case INPUT:     return parseInput();
                case SWAP:      return parseSwap();
                case SELF:      return parseSelfStatement();
                case SUPER:     return parseSuperStatement();
                default:        break;
            }

            if (isTypeKeyword())                                              return parseVarDecl();
            if (check(TokenType.IDENTIFIER) &&
                (peek(1).type == TokenType.IDENTIFIER || isTypeAt(peek(1)))) return parseVarDecl();
            if (check(TokenType.IDENTIFIER))                                  return parseIdentifierStatement();

            Token bad = cur();
            diag.error(bad.line, bad.col, "Parser",
                       "unexpected token '" + bad.value + "' — cannot start a statement",
                       null, null);
            throw new ParseError("unexpected token");

        } catch (ParseError e) {
            synchronize(TokenType.BLOCK_END);
            return null;
        } catch (StackOverflowError e) {
            Token here = pos < toks.size() ? cur() : toks.get(toks.size() - 1);
            diag.error(here.line, here.col, "Parser",
                       "expression or statement nested too deeply to parse",
                       "simplify this statement; extremely deep nesting is not supported", null);
            synchronize(TokenType.BLOCK_END);
            return null;
        }
    }

    private boolean isTypeAt(Token t) {
        switch (t.type) {
            case TYPE_INT: case TYPE_FLOAT: case TYPE_DOUBLE:
            case TYPE_CHAR: case TYPE_STRING: case TYPE_BOOL: case TYPE_VOID:
                return true;
            default: return false;
        }
    }

    private ASTNode parseVarDecl() {
        Token typeTok = advance();
        String type   = typeName(typeTok);
        Token nameTok = expect(TokenType.IDENTIFIER);
        ASTNode init  = null;
        if (match(TokenType.ASSIGN)) init = parseExpression();
        return new ASTNode.VarDecl(type, nameTok.value, init, typeTok.line);
    }

    private ASTNode parseIdentifierStatement() {
        Token id   = advance();
        String name = id.value;

        switch (cur().type) {
            case ASSIGN:    { advance(); return new ASTNode.Assign(name, parseExpression(), id.line); }
            case INCREMENT: { advance(); return new ASTNode.Increment(name, id.line); }
            case DECREMENT: { advance(); return new ASTNode.Decrement(name, id.line); }

            case DOT: {
                advance();
                Token member = expect(TokenType.IDENTIFIER);
                if (check(TokenType.LPAREN)) {
                    List<ASTNode> args = parseArgs();
                    ASTNode tgt = new ASTNode.Identifier(name, id.line);
                    return new ASTNode.ExprStat(
                        new ASTNode.MethodCall(tgt, member.value, args, id.line), id.line);
                }
                if (match(TokenType.ASSIGN)) {
                    ASTNode tgt = new ASTNode.Identifier(name, id.line);
                    return new ASTNode.MemberAssign(tgt, member.value, parseExpression(), id.line);
                }
                diag.error(member.line, member.col, "Parser",
                           "expected '(' for method call or '→' for field assignment after '" + name + "." + member.value + "'",
                           null, null);
                throw new ParseError("bad member stmt");
            }

            case LPAREN: {
                List<ASTNode> args = parseArgs();
                return new ASTNode.ExprStat(new ASTNode.Call(name, args, id.line), id.line);
            }

            default: {
                Token bad = cur();
                diag.error(bad.line, bad.col, "Parser",
                           "expected '→', '↑', '↓', '.', or '(' after identifier '" + name + "'",
                           null, null);
                throw new ParseError("bad identifier stmt");
            }
        }
    }

    private ASTNode parseSelfStatement() {
        int l = advance().line;
        expect(TokenType.DOT);
        Token member = expect(TokenType.IDENTIFIER);
        ASTNode self = new ASTNode.Self(l);

        if (check(TokenType.LPAREN)) {
            List<ASTNode> args = parseArgs();
            return new ASTNode.ExprStat(new ASTNode.MethodCall(self, member.value, args, l), l);
        }
        if (match(TokenType.ASSIGN)) {
            return new ASTNode.MemberAssign(self, member.value, parseExpression(), l);
        }
        diag.error(member.line, member.col, "Parser",
                   "expected '(' for method call or '→' for field assignment after 'self." + member.value + "'",
                   null, null);
        throw new ParseError("bad self stmt");
    }

    private ASTNode parseSuperStatement() {
        int l = advance().line;
        expect(TokenType.DOT);
        Token method = expect(TokenType.IDENTIFIER);
        ASTNode superNode = new ASTNode.Super(l);

        if (check(TokenType.LPAREN)) {
            List<ASTNode> args = parseArgs();
            return new ASTNode.ExprStat(new ASTNode.MethodCall(superNode, method.value, args, l), l);
        }
        if (match(TokenType.ASSIGN)) {
            return new ASTNode.MemberAssign(superNode, method.value, parseExpression(), l);
        }
        diag.error(method.line, method.col, "Parser",
                   "expected '(' or '→' after 'super." + method.value + "'",
                   null, null);
        throw new ParseError("bad super stmt");
    }

    private ASTNode parseSwap() {
        int l = advance().line;
        Token a = expect(TokenType.IDENTIFIER);
        Token b = expect(TokenType.IDENTIFIER);
        return new ASTNode.Swap(a.value, b.value, l);
    }

    private ASTNode parsePrint() {
        int l = advance().line;
        return new ASTNode.Print(parseExpression(), l);
    }

    private ASTNode parseInput() {
        int l = advance().line;
        Token name = expect(TokenType.IDENTIFIER);
        return new ASTNode.Input(name.value, l);
    }

    private ASTNode parseIf() {
        int l = advance().line;
        expect(TokenType.LPAREN);
        ASTNode cond = parseExpression();
        expect(TokenType.RPAREN);
        ASTNode.Block thenB = parseBlock();

        List<ASTNode.ElseIf> elseIfs = new ArrayList<>();
        ASTNode.Block elseB = null;

        while (check(TokenType.ELSE_IF)) {
            advance();
            expect(TokenType.LPAREN);
            ASTNode c = parseExpression();
            expect(TokenType.RPAREN);
            elseIfs.add(new ASTNode.ElseIf(c, parseBlock()));
        }
        if (check(TokenType.ELSE)) {
            advance();
            elseB = parseBlock();
        }
        return new ASTNode.If(cond, thenB, elseIfs, elseB, l);
    }

    private ASTNode parseLoop() {
        int l = advance().line;
        expect(TokenType.LPAREN);
        ASTNode cond = parseExpression();
        expect(TokenType.RPAREN);
        return new ASTNode.Loop(cond, parseBlock(), l);
    }

    private ASTNode parseReturn() {
        int l = advance().line;
        if (check(TokenType.BLOCK_END) || check(TokenType.EOF) || isNextStmtStart()) {
            return new ASTNode.Return(null, l);
        }
        return new ASTNode.Return(parseExpression(), l);
    }

    private boolean isNextStmtStart() {
        switch (cur().type) {
            case IF: case LOOP: case SWITCH: case BREAK: case CONTINUE:
            case PRINT: case INPUT: case SWAP: case FUNCTION: case CLASS:
            case INTERFACE: case ABSTRACT:
                return true;
            default: return false;
        }
    }

    private ASTNode parseSwitch() {
        int l = advance().line;
        expect(TokenType.LPAREN);
        ASTNode expr = parseExpression();
        expect(TokenType.RPAREN);
        expect(TokenType.BLOCK_START);

        List<ASTNode.Case> cases   = new ArrayList<>();
        ASTNode.Block      defBody = null;

        while (!check(TokenType.BLOCK_END) && !check(TokenType.EOF)) {
            if (match(TokenType.CASE)) {
                ASTNode val  = parseExpression();
                if (!isConstantCaseValue(val)) {
                    diag.error(val.line, 1, "Parser",
                               "switch case value must be a literal constant",
                               "case labels must be int, char, string, or bool literals — not a variable or expression",
                               null);
                }
                ASTNode.Block body = parseBlock();
                cases.add(new ASTNode.Case(val, body));
            } else if (check(TokenType.MULTIPLY)) {
                advance();
                if (defBody != null) {
                    diag.error(cur().line, cur().col, "Parser",
                               "duplicate default case in switch", null, null);
                }
                defBody = parseBlock();
            } else {
                Token bad = cur();
                diag.error(bad.line, bad.col, "Parser",
                           "expected '#' (case) or '*' (default) in switch body, found '" + bad.value + "'",
                           null, null);
                synchronize(TokenType.CASE, TokenType.MULTIPLY, TokenType.BLOCK_END);
            }
        }
        expectOrWarn(TokenType.BLOCK_END);
        return new ASTNode.Switch(expr, cases, defBody, l);
    }

    private boolean isConstantCaseValue(ASTNode n) {
        if (n instanceof ASTNode.IntLit
                || n instanceof ASTNode.CharLit
                || n instanceof ASTNode.StringLit
                || n instanceof ASTNode.BoolLit) {
            return true;
        }
        if (n instanceof ASTNode.Unary) {
            ASTNode.Unary u = (ASTNode.Unary) n;
            return "-".equals(u.op) && u.operand instanceof ASTNode.IntLit;
        }
        return false;
    }

    private ASTNode parseFunc(boolean isAbstract, boolean isOverride) {
        int l = advance().line;

        Token rtTok = cur();
        if (!isTypeKeyword() && !check(TokenType.IDENTIFIER)) {
            diag.error(rtTok.line, rtTok.col, "Parser",
                       "expected return type after 'ƒ', found '" + rtTok.value + "'",
                       "e.g. ƒ int myFunc() : ... ;", null);
            throw new ParseError("bad return type");
        }
        String returnType = typeName(advance());

        Token nameTok = expect(TokenType.IDENTIFIER);
        expect(TokenType.LPAREN);

        List<ASTNode.Param> params = new ArrayList<>();
        if (!check(TokenType.RPAREN)) {
            do {
                Token ptTok = cur();
                if (!isTypeKeyword() && !check(TokenType.IDENTIFIER)) {
                    diag.error(ptTok.line, ptTok.col, "Parser",
                               "expected parameter type, found '" + ptTok.value + "'",
                               null, null);
                    throw new ParseError("bad param type");
                }
                String pt = typeName(advance());
                Token pn  = expect(TokenType.IDENTIFIER);
                params.add(new ASTNode.Param(pt, pn.value));
            } while (match(TokenType.COMMA));
        }
        expect(TokenType.RPAREN);

        ASTNode.Block body = null;
        if (isAbstract) {
            expectOrWarn(TokenType.BLOCK_END);
        } else {
            body = parseBlock();
        }
        return new ASTNode.FuncDecl(returnType, nameTok.value, params, body,
                                    isAbstract, isOverride, l);
    }

    private ASTNode parseClass() {
        boolean isAbstract = match(TokenType.ABSTRACT);
        int l              = advance().line;
        boolean isInterface = toks.get(pos - 1).type == TokenType.INTERFACE;

        Token nameTok    = expect(TokenType.IDENTIFIER);
        String superClass = null;
        if (match(TokenType.EXTENDS)) {
            superClass = expect(TokenType.IDENTIFIER).value;
        }
        List<ASTNode> members = parseMembers();
        return new ASTNode.ClassDecl(nameTok.value, superClass, members,
                                     isAbstract, isInterface, l);
    }

    private ASTNode parseInterface() {
        int l         = advance().line;
        Token nameTok = expect(TokenType.IDENTIFIER);
        List<ASTNode> members = parseMembers();
        return new ASTNode.ClassDecl(nameTok.value, null, members, false, true, l);
    }

    private List<ASTNode> parseMembers() {
        expect(TokenType.BLOCK_START);
        List<ASTNode> members = new ArrayList<>();
        while (!check(TokenType.BLOCK_END) && !check(TokenType.EOF)) {
            int before = pos;
            ASTNode m = parseClassMemberRecovering();
            if (m != null) members.add(m);
            if (pos == before) {
                Token stuck = cur();
                diag.error(stuck.line, stuck.col, "Parser",
                           "unexpected token '" + stuck.value + "' in class body", null, null);
                advance();
            }
        }
        expectOrWarn(TokenType.BLOCK_END);
        return members;
    }

    private ASTNode parseClassMemberRecovering() {
        try {
            return parseClassMember();
        } catch (ParseError e) {
            synchronize(TokenType.BLOCK_END, TokenType.FUNCTION,
                        TokenType.ABSTRACT, TokenType.OVERRIDE);
            return null;
        } catch (StackOverflowError e) {
            Token here = cur();
            diag.error(here.line, here.col, "Parser",
                       "class member nested too deeply to parse", null, null);
            synchronize(TokenType.BLOCK_END, TokenType.FUNCTION,
                        TokenType.ABSTRACT, TokenType.OVERRIDE);
            return null;
        }
    }

    private ASTNode parseClassMember() {
        boolean isAbstract = match(TokenType.ABSTRACT);
        boolean isOverride = match(TokenType.OVERRIDE);
        if (check(TokenType.FUNCTION)) {
            return parseFunc(isAbstract, isOverride);
        }
        if (isTypeKeyword() || check(TokenType.IDENTIFIER)) {
            if (isAbstract || isOverride) {
                Token bad = cur();
                diag.error(bad.line, bad.col, "Parser",
                           "'abstract'/'override' modifier cannot be applied to a field",
                           "did you mean to declare a function with 'ƒ'?", null);
            }
            return parseVarDecl();
        }
        Token bad = cur();
        diag.error(bad.line, bad.col, "Parser",
                   "unexpected token '" + bad.value + "' in class body",
                   "expected a field declaration or 'ƒ' function", null);
        throw new ParseError("bad class member");
    }

    private ASTNode parseExpression() {
        exprDepth++;
        try {
            if (exprDepth > MAX_EXPR_DEPTH) {
                Token here = cur();
                diag.error(here.line, here.col, "Parser",
                           "expression nested too deeply (limit " + MAX_EXPR_DEPTH + ")",
                           "simplify this expression — extremely deep nesting is not supported",
                           null);
                throw new ParseError("expression too deep");
            }
            return parseOr();
        } finally {
            exprDepth--;
        }
    }

    private ASTNode parseOr() {
        ASTNode left = parseAnd();
        while (check(TokenType.OR)) {
            Token op = advance();
            left = new ASTNode.Binary("||", left, parseAnd(), op.line);
        }
        return left;
    }

    private ASTNode parseAnd() {
        ASTNode left = parseEquality();
        while (check(TokenType.AND)) {
            Token op = advance();
            left = new ASTNode.Binary("&&", left, parseEquality(), op.line);
        }
        return left;
    }

    private ASTNode parseEquality() {
        ASTNode left = parseComparison();
        while (check(TokenType.EQ) || check(TokenType.NEQ)) {
            Token op = advance();
            left = new ASTNode.Binary(op.value, left, parseComparison(), op.line);
        }
        return left;
    }

    private ASTNode parseComparison() {
        ASTNode left = parseAddition();
        while (check(TokenType.GT) || check(TokenType.LT) ||
               check(TokenType.GTE) || check(TokenType.LTE)) {
            Token op = advance();
            left = new ASTNode.Binary(op.value, left, parseAddition(), op.line);
        }
        return left;
    }

    private ASTNode parseAddition() {
        ASTNode left = parseMultiplication();
        while (check(TokenType.PLUS) || check(TokenType.MINUS)) {
            Token op = advance();
            left = new ASTNode.Binary(op.value, left, parseMultiplication(), op.line);
        }
        return left;
    }

    private ASTNode parseMultiplication() {
        ASTNode left = parseUnary();
        while (check(TokenType.MULTIPLY) || check(TokenType.DIVIDE) || check(TokenType.MODULO)) {
            Token op = advance();
            left = new ASTNode.Binary(op.value, left, parseUnary(), op.line);
        }
        return left;
    }

    private ASTNode parseUnary() {
        if (check(TokenType.NOT)) {
            Token op = advance();
            return new ASTNode.Unary("!", parseUnary(), op.line);
        }
        if (check(TokenType.MINUS)) {
            Token op = advance();
            return new ASTNode.Unary("-", parseUnary(), op.line);
        }
        return parsePostfix();
    }

    private ASTNode parsePostfix() {
        ASTNode expr = parsePrimary();
        while (check(TokenType.DOT)) {
            advance();
            Token member = expect(TokenType.IDENTIFIER);
            if (check(TokenType.LPAREN)) {
                List<ASTNode> args = parseArgs();
                expr = new ASTNode.MethodCall(expr, member.value, args, member.line);
            } else {
                expr = new ASTNode.MemberAccess(expr, member.value, member.line);
            }
        }
        return expr;
    }

    private ASTNode parsePrimary() {
        Token t = cur();
        switch (t.type) {
            case INT_LIT:    advance(); return new ASTNode.IntLit(parseIntSafe(t), t.line);
            case FLOAT_LIT:  advance(); return new ASTNode.FloatLit(parseFloatSafe(t), t.line);
            case STRING_LIT: advance(); return new ASTNode.StringLit(t.value, t.line);
            case CHAR_LIT:   advance(); return new ASTNode.CharLit(t.value.isEmpty() ? '\0' : t.value.charAt(0), t.line);
            case BOOL_TRUE:  advance(); return new ASTNode.BoolLit(true, t.line);
            case BOOL_FALSE: advance(); return new ASTNode.BoolLit(false, t.line);
            case NULL_LIT:   advance(); return new ASTNode.NullLit(t.line);
            case SELF:       advance(); return new ASTNode.Self(t.line);
            case SUPER:      advance(); return new ASTNode.Super(t.line);

            case NEW: {
                advance();
                Token cls = expect(TokenType.IDENTIFIER);
                List<ASTNode> args = parseArgs();
                return new ASTNode.NewObject(cls.value, args, t.line);
            }

            case IDENTIFIER: {
                advance();
                if (check(TokenType.LPAREN)) {
                    List<ASTNode> args = parseArgs();
                    return new ASTNode.Call(t.value, args, t.line);
                }
                return new ASTNode.Identifier(t.value, t.line);
            }

            case LPAREN: {
                advance();
                ASTNode inner = parseExpression();
                expect(TokenType.RPAREN);
                return inner;
            }

            case TYPE_INT: case TYPE_FLOAT: case TYPE_DOUBLE:
            case TYPE_CHAR: case TYPE_STRING: case TYPE_BOOL: case TYPE_VOID: {
                diag.error(t.line, t.col, "Parser",
                           "type keyword '" + t.value + "' cannot appear in an expression",
                           "did you forget a variable name?", null);
                advance();
                return new ASTNode.Identifier(t.value, t.line);
            }

            default: {
                diag.error(t.line, t.col, "Parser",
                           "unexpected token '" + t.value + "' in expression",
                           null, null);
                throw new ParseError("unexpected in expr: " + t.value);
            }
        }
    }

    private int parseIntSafe(Token t) {
        try {
            return Integer.parseInt(t.value);
        } catch (NumberFormatException e) {
            diag.error(t.line, t.col, "Parser",
                       "internal: could not interpret '" + t.value + "' as an integer literal",
                       null, null);
            return 0;
        }
    }

    private double parseFloatSafe(Token t) {
        try {
            return Double.parseDouble(t.value);
        } catch (NumberFormatException e) {
            diag.error(t.line, t.col, "Parser",
                       "internal: could not interpret '" + t.value + "' as a floating-point literal",
                       null, null);
            return 0.0;
        }
    }

    private List<ASTNode> parseArgs() {
        expect(TokenType.LPAREN);
        List<ASTNode> args = new ArrayList<>();
        if (!check(TokenType.RPAREN)) {
            do {
                args.add(parseExpression());
            } while (match(TokenType.COMMA));
        }
        expect(TokenType.RPAREN);
        return args;
    }

    private static String humanName(TokenType t) {
        switch (t) {
            case BLOCK_START: return "':' (block open)";
            case BLOCK_END:   return "';' (block close)";
            case LPAREN:      return "'('";
            case RPAREN:      return "')'";
            case ASSIGN:      return "'→' (assignment)";
            case IDENTIFIER:  return "identifier";
            case COMMA:       return "','";
            case DOT:         return "'.'";
            case EOF:         return "end of file";
            default:          return t.name();
        }
    }

    private static String tokenChar(TokenType t) {
        switch (t) {
            case BLOCK_START: return ":";
            case BLOCK_END:   return ";";
            case LPAREN:      return "(";
            case RPAREN:      return ")";
            default:          return t.name();
        }
    }

    private static String hintForMissing(TokenType expected, Token found) {
        if (expected == TokenType.ASSIGN && found.value.equals("="))
            return "Arrow uses '→' (U+2192) for assignment, not '='";
        if (expected == TokenType.BLOCK_START && found.value.equals("{"))
            return "Arrow uses ':' to open a block, not '{'";
        if (expected == TokenType.BLOCK_END && found.value.equals("}"))
            return "Arrow uses ';' to close a block, not '}'";
        return null;
    }
}
