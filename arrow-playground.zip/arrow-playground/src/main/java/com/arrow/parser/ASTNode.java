package com.arrow.parser;

import java.util.List;

public abstract class ASTNode {
    public int line;

    public interface Visitor<T> {
        T visitProgram(Program n);
        T visitBlock(Block n);
        T visitVarDecl(VarDecl n);
        T visitAssign(Assign n);
        T visitMemberAssign(MemberAssign n);
        T visitIncrement(Increment n);
        T visitDecrement(Decrement n);
        T visitSwap(Swap n);
        T visitPrint(Print n);
        T visitInput(Input n);
        T visitIf(If n);
        T visitLoop(Loop n);
        T visitBreak(Break n);
        T visitContinue(Continue n);
        T visitReturn(Return n);
        T visitSwitch(Switch n);
        T visitFuncDecl(FuncDecl n);
        T visitClassDecl(ClassDecl n);
        T visitExprStat(ExprStat n);
        T visitIntLit(IntLit n);
        T visitFloatLit(FloatLit n);
        T visitStringLit(StringLit n);
        T visitCharLit(CharLit n);
        T visitBoolLit(BoolLit n);
        T visitNullLit(NullLit n);
        T visitIdentifier(Identifier n);
        T visitBinary(Binary n);
        T visitUnary(Unary n);
        T visitCall(Call n);
        T visitMemberAccess(MemberAccess n);
        T visitMethodCall(MethodCall n);
        T visitNewObject(NewObject n);
        T visitSelf(Self n);
        T visitSuper(Super n);
    }

    public abstract <T> T accept(Visitor<T> v);

    public static class Program extends ASTNode {
        public List<ASTNode> statements;
        public Program(List<ASTNode> s) { statements = s; }
        public <T> T accept(Visitor<T> v) { return v.visitProgram(this); }
    }
    public static class Block extends ASTNode {
        public List<ASTNode> statements;
        public Block(List<ASTNode> s, int l) { statements = s; line = l; }
        public <T> T accept(Visitor<T> v) { return v.visitBlock(this); }
    }

    public static class VarDecl extends ASTNode {
        public String type, name; public ASTNode init;
        public VarDecl(String t, String n, ASTNode i, int l){type=t;name=n;init=i;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitVarDecl(this);}
    }
    public static class Assign extends ASTNode {
        public String name; public ASTNode value;
        public Assign(String n, ASTNode val, int l){name=n;value=val;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitAssign(this);}
    }
    public static class MemberAssign extends ASTNode {
        public ASTNode target; public String field; public ASTNode value;
        public MemberAssign(ASTNode t, String f, ASTNode val, int l){target=t;field=f;value=val;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitMemberAssign(this);}
    }
    public static class Increment extends ASTNode {
        public String name; public Increment(String n,int l){name=n;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitIncrement(this);}
    }
    public static class Decrement extends ASTNode {
        public String name; public Decrement(String n,int l){name=n;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitDecrement(this);}
    }
    public static class Swap extends ASTNode {
        public String a,b; public Swap(String a,String b,int l){this.a=a;this.b=b;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitSwap(this);}
    }
    public static class Print extends ASTNode {
        public ASTNode expr; public Print(ASTNode e,int l){expr=e;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitPrint(this);}
    }
    public static class Input extends ASTNode {
        public String name; public Input(String n,int l){name=n;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitInput(this);}
    }
    public static class If extends ASTNode {
        public ASTNode cond; public Block thenB;
        public List<ElseIf> elseIfs; public Block elseB;
        public If(ASTNode c,Block t,List<ElseIf> ei,Block e,int l){cond=c;thenB=t;elseIfs=ei;elseB=e;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitIf(this);}
    }
    public static class ElseIf { public ASTNode cond; public Block body;
        public ElseIf(ASTNode c,Block b){cond=c;body=b;} }
    public static class Loop extends ASTNode {
        public ASTNode cond; public Block body;
        public Loop(ASTNode c,Block b,int l){cond=c;body=b;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitLoop(this);}
    }
    public static class Break extends ASTNode {
        public Break(int l){line=l;} public <T> T accept(Visitor<T> v){return v.visitBreak(this);}
    }
    public static class Continue extends ASTNode {
        public Continue(int l){line=l;} public <T> T accept(Visitor<T> v){return v.visitContinue(this);}
    }
    public static class Return extends ASTNode {
        public ASTNode value; public Return(ASTNode v,int l){value=v;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitReturn(this);}
    }
    public static class Switch extends ASTNode {
        public ASTNode expr; public List<Case> cases; public Block defaultBody;
        public Switch(ASTNode e,List<Case> c,Block d,int l){expr=e;cases=c;defaultBody=d;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitSwitch(this);}
    }
    public static class Case { public ASTNode value; public Block body;
        public Case(ASTNode v,Block b){value=v;body=b;} }

    public static class FuncDecl extends ASTNode {
        public String returnType, name;
        public List<Param> params; public Block body;
        public boolean isAbstract, isOverride;
        public FuncDecl(String rt,String n,List<Param> p,Block b,boolean a,boolean o,int l){
            returnType=rt;name=n;params=p;body=b;isAbstract=a;isOverride=o;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitFuncDecl(this);}
    }
    public static class Param { public String type,name;
        public Param(String t,String n){type=t;name=n;} }
    public static class ClassDecl extends ASTNode {
        public String name, superClass;
        public List<ASTNode> members; public boolean isAbstract, isInterface;
        public ClassDecl(String n,String sc,List<ASTNode> m,boolean a,boolean i,int l){
            name=n;superClass=sc;members=m;isAbstract=a;isInterface=i;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitClassDecl(this);}
    }
    public static class ExprStat extends ASTNode {
        public ASTNode expr; public ExprStat(ASTNode e,int l){expr=e;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitExprStat(this);}
    }

    public static class IntLit extends ASTNode { public int value;
        public IntLit(int v,int l){value=v;line=l;} public <T> T accept(Visitor<T> v){return v.visitIntLit(this);} }
    public static class FloatLit extends ASTNode { public double value;
        public FloatLit(double v,int l){value=v;line=l;} public <T> T accept(Visitor<T> v){return v.visitFloatLit(this);} }
    public static class StringLit extends ASTNode { public String value;
        public StringLit(String v,int l){value=v;line=l;} public <T> T accept(Visitor<T> v){return v.visitStringLit(this);} }
    public static class CharLit extends ASTNode { public char value;
        public CharLit(char v,int l){value=v;line=l;} public <T> T accept(Visitor<T> v){return v.visitCharLit(this);} }
    public static class BoolLit extends ASTNode { public boolean value;
        public BoolLit(boolean v,int l){value=v;line=l;} public <T> T accept(Visitor<T> v){return v.visitBoolLit(this);} }
    public static class NullLit extends ASTNode {
        public NullLit(int l){line=l;} public <T> T accept(Visitor<T> v){return v.visitNullLit(this);} }
    public static class Identifier extends ASTNode { public String name;
        public Identifier(String n,int l){name=n;line=l;} public <T> T accept(Visitor<T> v){return v.visitIdentifier(this);} }
    public static class Binary extends ASTNode { public String op; public ASTNode left,right;
        public Binary(String o,ASTNode l,ASTNode r,int ln){op=o;left=l;right=r;line=ln;}
        public <T> T accept(Visitor<T> v){return v.visitBinary(this);} }
    public static class Unary extends ASTNode { public String op; public ASTNode operand;
        public Unary(String o,ASTNode e,int l){op=o;operand=e;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitUnary(this);} }
    public static class Call extends ASTNode { public String name; public List<ASTNode> args;
        public Call(String n,List<ASTNode> a,int l){name=n;args=a;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitCall(this);} }
    public static class MemberAccess extends ASTNode { public ASTNode target; public String field;
        public MemberAccess(ASTNode t,String f,int l){target=t;field=f;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitMemberAccess(this);} }
    public static class MethodCall extends ASTNode { public ASTNode target; public String method; public List<ASTNode> args;
        public MethodCall(ASTNode t,String m,List<ASTNode> a,int l){target=t;method=m;args=a;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitMethodCall(this);} }
    public static class NewObject extends ASTNode { public String className; public List<ASTNode> args;
        public NewObject(String c,List<ASTNode> a,int l){className=c;args=a;line=l;}
        public <T> T accept(Visitor<T> v){return v.visitNewObject(this);} }
    public static class Self extends ASTNode {
        public Self(int l){line=l;} public <T> T accept(Visitor<T> v){return v.visitSelf(this);} }
    public static class Super extends ASTNode {
        public Super(int l){line=l;} public <T> T accept(Visitor<T> v){return v.visitSuper(this);}
    }
}
