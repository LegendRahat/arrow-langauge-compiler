package com.arrow.parser;

import com.arrow.parser.ASTNode.*;
import java.util.List;

/** Renders the AST as a textual tree (used for the AST viewer modal in the UI). */
public class ParseTree {

    public static String render(Program p) {
        StringBuilder sb = new StringBuilder();
        sb.append("---------- AST ----------\n");
        sb.append("Program\n");
        List<ASTNode> s = p.statements;
        for (int i = 0; i < s.size(); i++) node(sb, s.get(i), "", i == s.size() - 1);
        sb.append("-------------------------\n");
        return sb.toString();
    }

    private static void node(StringBuilder sb, ASTNode n, String pre, boolean last) {
        String conn = last ? "`-- " : "|-- ";
        String cpre = pre + (last ? "    " : "|   ");
        sb.append(pre).append(conn).append(label(n)).append("\n");

        if (n instanceof VarDecl) { VarDecl v = (VarDecl) n; if (v.init != null) node(sb, v.init, cpre, true); }
        else if (n instanceof Assign) node(sb, ((Assign) n).value, cpre, true);
        else if (n instanceof Print) node(sb, ((Print) n).expr, cpre, true);
        else if (n instanceof Return) { Return r = (Return) n; if (r.value != null) node(sb, r.value, cpre, true); }
        else if (n instanceof Binary) { Binary b = (Binary) n; node(sb, b.left, cpre, false); node(sb, b.right, cpre, true); }
        else if (n instanceof Unary) node(sb, ((Unary) n).operand, cpre, true);
        else if (n instanceof ExprStat) node(sb, ((ExprStat) n).expr, cpre, true);
        else if (n instanceof Block) block(sb, "block", ((Block) n).statements, cpre, true);
        else if (n instanceof If) {
            If f = (If) n;
            node(sb, f.cond, cpre, false);
            block(sb, "then", f.thenB.statements, cpre, f.elseIfs.isEmpty() && f.elseB == null);
            for (int i = 0; i < f.elseIfs.size(); i++) {
                ElseIf ei = f.elseIfs.get(i);
                boolean l = (i == f.elseIfs.size() - 1) && f.elseB == null;
                node(sb, ei.cond, cpre, false);
                block(sb, "else-if", ei.body.statements, cpre, l);
            }
            if (f.elseB != null) block(sb, "else", f.elseB.statements, cpre, true);
        }
        else if (n instanceof Loop) { Loop lp = (Loop) n; node(sb, lp.cond, cpre, false); block(sb, "body", lp.body.statements, cpre, true); }
        else if (n instanceof ClassDecl) { ClassDecl c = (ClassDecl) n; block(sb, "members", c.members, cpre, true); }
        else if (n instanceof FuncDecl) { FuncDecl fn = (FuncDecl) n; if (fn.body != null) block(sb, "body", fn.body.statements, cpre, true); }
        else if (n instanceof Switch) {
            Switch sw = (Switch) n;
            node(sb, sw.expr, cpre, false);
            for (int i = 0; i < sw.cases.size(); i++) {
                Case c = sw.cases.get(i);
                boolean l = (i == sw.cases.size() - 1) && sw.defaultBody == null;
                node(sb, c.value, cpre, false);
                block(sb, "case-body", c.body.statements, cpre, l);
            }
            if (sw.defaultBody != null) block(sb, "default", sw.defaultBody.statements, cpre, true);
        }
    }

    private static void block(StringBuilder sb, String name, List<ASTNode> stmts, String pre, boolean last) {
        String conn = last ? "`-- " : "|-- ";
        String npre = pre + (last ? "    " : "|   ");
        sb.append(pre).append(conn).append("[").append(name).append("]\n");
        for (int i = 0; i < stmts.size(); i++) node(sb, stmts.get(i), npre, i == stmts.size() - 1);
    }

    private static String label(ASTNode n) {
        if (n instanceof VarDecl) { VarDecl v = (VarDecl) n; return "VarDecl [" + v.type + " " + v.name + "]"; }
        if (n instanceof Assign) return "Assign [" + ((Assign) n).name + "]";
        if (n instanceof Increment) return "Increment [" + ((Increment) n).name + "]";
        if (n instanceof Decrement) return "Decrement [" + ((Decrement) n).name + "]";
        if (n instanceof Swap) { Swap s = (Swap) n; return "Swap [" + s.a + "," + s.b + "]"; }
        if (n instanceof Print) return "Print";
        if (n instanceof Input) return "Input [" + ((Input) n).name + "]";
        if (n instanceof If) return "If";
        if (n instanceof Loop) return "Loop";
        if (n instanceof Break) return "Break";
        if (n instanceof Continue) return "Continue";
        if (n instanceof Return) return "Return";
        if (n instanceof Switch) return "Switch";
        if (n instanceof ClassDecl) {
            ClassDecl c = (ClassDecl) n;
            return (c.isInterface ? "Interface [" : c.isAbstract ? "AbstractClass [" : "Class [") + c.name +
                   (c.superClass != null ? " extends " + c.superClass : "") + "]";
        }
        if (n instanceof FuncDecl) {
            FuncDecl f = (FuncDecl) n;
            return (f.isOverride ? "override " : "") + (f.isAbstract ? "abstract " : "") + "Func [" + f.returnType + " " + f.name + "]";
        }
        if (n instanceof ExprStat) return "ExprStat";
        if (n instanceof IntLit) return "Int [" + ((IntLit) n).value + "]";
        if (n instanceof FloatLit) return "Float [" + ((FloatLit) n).value + "]";
        if (n instanceof StringLit) return "String [\"" + ((StringLit) n).value + "\"]";
        if (n instanceof CharLit) return "Char ['" + ((CharLit) n).value + "']";
        if (n instanceof BoolLit) return "Bool [" + (((BoolLit) n).value ? "true" : "false") + "]";
        if (n instanceof NullLit) return "Null";
        if (n instanceof Identifier) return "Id [" + ((Identifier) n).name + "]";
        if (n instanceof Binary) return "Binary [" + ((Binary) n).op + "]";
        if (n instanceof Unary) return "Unary [" + ((Unary) n).op + "]";
        if (n instanceof Call) return "Call [" + ((Call) n).name + "]";
        if (n instanceof MemberAccess) return "Member [." + ((MemberAccess) n).field + "]";
        if (n instanceof MethodCall) return "MethodCall [." + ((MethodCall) n).method + "]";
        if (n instanceof NewObject) return "New [" + ((NewObject) n).className + "]";
        if (n instanceof Self) return "self";
        if (n instanceof Super) return "super";
        if (n instanceof MemberAssign) return "MemberAssign [." + ((MemberAssign) n).field + "]";
        return n.getClass().getSimpleName();
    }
}
