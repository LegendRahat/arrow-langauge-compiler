package com.arrow.semantic;

import com.arrow.diagnostic.DiagnosticBag;
import com.arrow.parser.ASTNode;
import com.arrow.parser.ASTNode.*;

/**
 * Arrow semantic analyser.
 *
 *  1. Integrated with DiagnosticBag — semantic errors collected, not thrown.
 *  2. visitFuncDecl manually iterates body.statements (params + body share one scope,
 *     avoiding a double-nested scope that Block.accept() would otherwise create).
 *  3. Undefined-symbol errors include a closest-match typo suggestion.
 *  4. Self/super checks produce diagnostics instead of exceptions.
 *  5. All visitor methods are null-safe (nodes may be null from parser recovery).
 */
public final class SemanticAnalyzer implements ASTNode.Visitor<String> {

    private final DiagnosticBag diag;
    private final SymbolTable   symbols = new SymbolTable();
    private int    loopDepth   = 0;
    private int    funcDepth   = 0;
    private String currentClass = null;

    public SemanticAnalyzer(DiagnosticBag diag) {
        this.diag = diag;
    }

    public void analyze(Program p) {
        if (p == null) return;

        for (ASTNode s : p.statements) {
            if (s == null) continue;
            if (s instanceof ClassDecl) {
                ClassDecl c = (ClassDecl) s;
                declareGlobalSafe(c.name, c.isInterface ? "interface" : "class", c.line);
            } else if (s instanceof FuncDecl) {
                FuncDecl f = (FuncDecl) s;
                declareGlobalSafe(f.name, "func", f.line);
            }
        }

        p.accept(this);
    }

    private void declareGlobalSafe(String name, String type, int line) {
        if (symbols.isDeclared(name)) {
            diag.warning(line, 1, "Semantic",
                         "'" + name + "' already declared globally — skipping re-declaration",
                         null);
        } else {
            symbols.declareGlobal(name, type, line);
        }
    }

    private void declareSafe(String name, String type, int line) {
        if (symbols.isInCurrentScope(name)) {
            diag.error(line, 1, "Semantic",
                       "'" + name + "' is already declared in this scope",
                       "rename the variable or use a different scope", null);
        } else {
            symbols.declare(name, type, line);
        }
    }

    private String resolveSafe(String name, int line) {
        String t = symbols.lookup(name);
        if (t == null) {
            String suggestion = symbols.closestMatch(name);
            String hint = suggestion != null ? "did you mean '" + suggestion + "'?" : null;
            diag.error(line, 1, "Semantic",
                       "undefined symbol '" + name + "'",
                       hint, null);
            return "unknown";
        }
        return t;
    }

    private void visit(ASTNode n) {
        if (n != null) n.accept(this);
    }

    @Override public String visitProgram(Program n) {
        for (ASTNode s : n.statements) visit(s);
        return null;
    }

    @Override public String visitBlock(Block n) {
        symbols.enterScope();
        for (ASTNode s : n.statements) visit(s);
        symbols.exitScope();
        return null;
    }

    @Override public String visitVarDecl(VarDecl n) {
        if (n.init != null) n.init.accept(this);
        declareSafe(n.name, n.type, n.line);
        return null;
    }

    @Override public String visitAssign(Assign n) {
        resolveSafe(n.name, n.line);
        visit(n.value);
        return null;
    }

    @Override public String visitMemberAssign(MemberAssign n) {
        visit(n.target);
        visit(n.value);
        return null;
    }

    @Override public String visitIncrement(Increment n) { resolveSafe(n.name, n.line); return null; }
    @Override public String visitDecrement(Decrement n) { resolveSafe(n.name, n.line); return null; }

    @Override public String visitSwap(Swap n) {
        resolveSafe(n.a, n.line);
        resolveSafe(n.b, n.line);
        return null;
    }

    @Override public String visitPrint(Print n) { visit(n.expr); return null; }

    @Override public String visitInput(Input n) {
        resolveSafe(n.name, n.line);
        return null;
    }

    @Override public String visitIf(If n) {
        visit(n.cond);
        visit(n.thenB);
        for (ElseIf ei : n.elseIfs) { visit(ei.cond); visit(ei.body); }
        if (n.elseB != null) visit(n.elseB);
        return null;
    }

    @Override public String visitLoop(Loop n) {
        visit(n.cond);
        loopDepth++;
        visit(n.body);
        loopDepth--;
        return null;
    }

    @Override public String visitBreak(Break n) {
        if (loopDepth == 0)
            diag.error(n.line, 1, "Semantic", "'↯' (break) used outside a loop",
                       "break can only appear inside a '⟲' loop body", null);
        return null;
    }

    @Override public String visitContinue(Continue n) {
        if (loopDepth == 0)
            diag.error(n.line, 1, "Semantic", "'↷' (continue) used outside a loop",
                       "continue can only appear inside a '⟲' loop body", null);
        return null;
    }

    @Override public String visitReturn(Return n) {
        if (funcDepth == 0)
            diag.error(n.line, 1, "Semantic", "'←' (return) used outside a function",
                       "return can only appear inside a 'ƒ' function body", null);
        if (n.value != null) visit(n.value);
        return null;
    }

    @Override public String visitSwitch(Switch n) {
        visit(n.expr);
        for (Case c : n.cases) { visit(c.value); visit(c.body); }
        if (n.defaultBody != null) visit(n.defaultBody);
        return null;
    }

    @Override public String visitFuncDecl(FuncDecl n) {
        if (currentClass == null && !symbols.isDeclared(n.name)) {
            declareSafe(n.name, "func", n.line);
        }

        funcDepth++;
        symbols.enterScope();
        for (Param p : n.params) declareSafe(p.name, p.type, n.line);

        if (n.body != null) {
            for (ASTNode s : n.body.statements) visit(s);
        }

        symbols.exitScope();
        funcDepth--;
        return null;
    }

    @Override public String visitClassDecl(ClassDecl n) {
        if (n.superClass != null && !symbols.isDeclared(n.superClass)) {
            diag.warning(n.line, 1, "Semantic",
                         "superclass '" + n.superClass + "' has not been declared yet",
                         "forward references may work if declared later in the file", null);
        }

        String prev = currentClass;
        currentClass = n.name;
        symbols.enterScope();

        for (ASTNode m : n.members) {
            if (m instanceof VarDecl) {
                VarDecl f = (VarDecl) m;
                if (f.init != null) visit(f.init);
                declareSafe(f.name, f.type, f.line);
            }
        }
        for (ASTNode m : n.members) {
            if (m instanceof FuncDecl) visit(m);
        }

        symbols.exitScope();
        currentClass = prev;
        return null;
    }

    @Override public String visitExprStat(ExprStat n) { visit(n.expr); return null; }

    @Override public String visitIntLit(IntLit n)       { return "int"; }
    @Override public String visitFloatLit(FloatLit n)   { return "float"; }
    @Override public String visitStringLit(StringLit n) { return "string"; }
    @Override public String visitCharLit(CharLit n)     { return "char"; }
    @Override public String visitBoolLit(BoolLit n)     { return "bool"; }
    @Override public String visitNullLit(NullLit n)     { return "null"; }

    @Override public String visitIdentifier(Identifier n) { return resolveSafe(n.name, n.line); }

    @Override public String visitBinary(Binary n) {
        String l = n.left  != null ? n.left.accept(this)  : "unknown";
        String r = n.right != null ? n.right.accept(this) : "unknown";
        switch (n.op) {
            case ">": case "<": case ">=": case "<=":
            case "==": case "!=": case "&&": case "||": return "bool";
        }
        if ("float".equals(l) || "float".equals(r) ||
            "double".equals(l) || "double".equals(r)) return "float";
        if ("+".equals(n.op) && ("string".equals(l) || "string".equals(r))) return "string";
        return l != null ? l : "unknown";
    }

    @Override public String visitUnary(Unary n) {
        String t = n.operand != null ? n.operand.accept(this) : "unknown";
        return "!".equals(n.op) ? "bool" : t;
    }

    @Override public String visitCall(Call n) {
        for (ASTNode a : n.args) visit(a);
        return "unknown";
    }

    @Override public String visitMemberAccess(MemberAccess n) {
        visit(n.target);
        return "unknown";
    }

    @Override public String visitMethodCall(MethodCall n) {
        visit(n.target);
        for (ASTNode a : n.args) visit(a);
        return "unknown";
    }

    @Override public String visitNewObject(NewObject n) {
        for (ASTNode a : n.args) visit(a);
        return n.className;
    }

    @Override public String visitSelf(Self n) {
        if (currentClass == null)
            diag.error(n.line, 1, "Semantic", "'self' used outside a class",
                       "'self' can only be used inside a '◈' class body", null);
        return currentClass != null ? currentClass : "unknown";
    }

    @Override public String visitSuper(Super n) {
        if (currentClass == null)
            diag.error(n.line, 1, "Semantic", "'super' used outside a class",
                       "'super' can only be used inside a '◈' class body", null);
        return "super";
    }
}
