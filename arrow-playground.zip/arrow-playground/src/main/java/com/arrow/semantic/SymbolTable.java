package com.arrow.semantic;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Lexically-scoped symbol table.
 *
 *  1. isInCurrentScope(String) — distinguishes same-scope redeclaration from
 *     shadowing an outer scope (a warning, not an error).
 *  2. closestMatch(String) — Levenshtein-based typo suggestion, e.g.
 *     "undefined 'lenght' — did you mean 'length'?"
 *  3. Uses ArrayDeque instead of Stack.
 *  4. Never throws; callers query and decide.
 */
public final class SymbolTable {

    private final Deque<Map<String, String>> scopes = new ArrayDeque<>();

    public SymbolTable() {
        scopes.push(new HashMap<>());
    }

    public void enterScope() { scopes.push(new HashMap<>()); }

    public void exitScope() {
        if (scopes.size() > 1) scopes.pop();
    }

    public void declare(String name, String type, int line) {
        scopes.peek().put(name, type);
    }

    public void declareGlobal(String name, String type, int line) {
        scopes.peekLast().put(name, type);
    }

    public String lookup(String name) {
        for (Map<String, String> scope : scopes) {
            String t = scope.get(name);
            if (t != null) return t;
        }
        return null;
    }

    public boolean isDeclared(String name) { return lookup(name) != null; }

    public boolean isInCurrentScope(String name) {
        return scopes.peek().containsKey(name);
    }

    public String resolve(String name, int line) {
        return lookup(name);
    }

    public String closestMatch(String name) {
        String best  = null;
        int    bestD = 3;
        for (Map<String, String> scope : scopes) {
            for (String candidate : scope.keySet()) {
                int d = levenshtein(name.toLowerCase(), candidate.toLowerCase());
                if (d < bestD) {
                    bestD = d;
                    best  = candidate;
                }
            }
        }
        return best;
    }

    public void dump() {
        System.out.println("---- Symbol Table ----");
        int i = 0;
        for (Map<String, String> scope : scopes) {
            System.out.println("  scope[" + i++ + "] " + scope);
        }
        System.out.println("-----------------------");
    }

    private static int levenshtein(String a, String b) {
        int la = a.length(), lb = b.length();
        int[][] dp = new int[la + 1][lb + 1];
        for (int i = 0; i <= la; i++) dp[i][0] = i;
        for (int j = 0; j <= lb; j++) dp[0][j] = j;
        for (int i = 1; i <= la; i++) {
            for (int j = 1; j <= lb; j++) {
                int cost = a.charAt(i-1) == b.charAt(j-1) ? 0 : 1;
                dp[i][j] = Math.min(
                    Math.min(dp[i-1][j] + 1, dp[i][j-1] + 1),
                    dp[i-1][j-1] + cost
                );
            }
        }
        return dp[la][lb];
    }
}
