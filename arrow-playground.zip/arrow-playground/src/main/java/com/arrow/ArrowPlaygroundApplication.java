package com.arrow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Arrow Language Playground.
 * Run with: mvn spring-boot:run
 * Then open http://localhost:8080
 */
@SpringBootApplication
public class ArrowPlaygroundApplication {
    public static void main(String[] args) {
        SpringApplication.run(ArrowPlaygroundApplication.class, args);
    }
}
