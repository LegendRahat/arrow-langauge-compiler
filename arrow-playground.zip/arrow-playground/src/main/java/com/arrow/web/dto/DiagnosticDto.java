package com.arrow.web.dto;

import com.arrow.diagnostic.Diagnostic;

public class DiagnosticDto {
    public String level;
    public int line;
    public int col;
    public String phase;
    public String message;
    public String hint;
    public String sourceLine;

    public DiagnosticDto() {}

    public static DiagnosticDto from(Diagnostic d) {
        DiagnosticDto dto = new DiagnosticDto();
        dto.level = d.level.name().toLowerCase();
        dto.line = d.line;
        dto.col = d.col;
        dto.phase = d.phase;
        dto.message = d.message;
        dto.hint = d.hint;
        dto.sourceLine = d.sourceLine;
        return dto;
    }
}
