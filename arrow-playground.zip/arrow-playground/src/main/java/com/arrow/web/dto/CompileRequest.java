package com.arrow.web.dto;

public class CompileRequest {
    public String source;

    public CompileRequest() {}
    public CompileRequest(String source) { this.source = source; }
}
