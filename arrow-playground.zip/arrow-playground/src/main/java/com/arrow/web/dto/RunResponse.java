package com.arrow.web.dto;

import java.util.List;

public class RunResponse {
    public boolean success;
    public String output;
    public String runtimeError; // nullable
    public List<DiagnosticDto> diagnostics;
    public int errorCount;
    public int warningCount;

    public RunResponse() {}
}
