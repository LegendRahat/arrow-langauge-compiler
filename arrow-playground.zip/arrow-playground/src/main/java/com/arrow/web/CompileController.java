package com.arrow.web;

import com.arrow.diagnostic.Diagnostic;
import com.arrow.web.dto.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CompileController {

    private final CompilerService compilerService;
    private final AiGenerationService aiService;

    public CompileController(CompilerService compilerService, AiGenerationService aiService) {
        this.compilerService = compilerService;
        this.aiService = aiService;
    }

    @PostMapping("/compile")
    public CompileResponse compile(@RequestBody CompileRequest req) {
        String source = req.source != null ? req.source : "";
        CompilerService.CompileResult r = compilerService.compile(source);

        CompileResponse resp = new CompileResponse();
        resp.success = r.success();
        resp.javaCode = r.javaCode;
        resp.astText = r.astText;
        resp.diagnostics = toDtoList(r.diag.sorted());
        resp.errorCount = r.diag.errorCount();
        resp.warningCount = r.diag.warningCount();
        return resp;
    }

    @PostMapping("/run")
    public RunResponse run(@RequestBody CompileRequest req) {
        String source = req.source != null ? req.source : "";
        CompilerService.RunResult r = compilerService.run(source);

        RunResponse resp = new RunResponse();
        resp.success = r.compile.success() && (r.sim == null || r.sim.error == null);
        resp.diagnostics = toDtoList(r.compile.diag.sorted());
        resp.errorCount = r.compile.diag.errorCount();
        resp.warningCount = r.compile.diag.warningCount();
        if (r.sim != null) {
            resp.output = r.sim.output;
            resp.runtimeError = r.sim.error;
        } else {
            resp.output = "";
            resp.runtimeError = null;
        }
        return resp;
    }

    @PostMapping("/ai-generate")
    public AiGenerateResponse aiGenerate(@RequestBody AiGenerateRequest req) {
        String prompt = req.prompt != null ? req.prompt : "";
        if (prompt.isBlank()) {
            AiGenerateResponse resp = new AiGenerateResponse();
            resp.success = false;
            resp.attempts = 0;
            resp.message = "Please provide a prompt describing what you want.";
            resp.code = "";
            return resp;
        }
        return aiService.generate(prompt);
    }

    private List<DiagnosticDto> toDtoList(List<Diagnostic> diags) {
        return diags.stream().map(DiagnosticDto::from).collect(Collectors.toList());
    }
}
