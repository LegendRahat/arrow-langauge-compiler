package com.arrow.web;

import com.arrow.web.dto.AiGenerateResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Calls OpenRouter's chat completions endpoint to generate Arrow source code from
 * a plain-English prompt, then compiles the result with the real Arrow compiler
 * pipeline and retries with error feedback (up to MAX_ATTEMPTS times) until the
 * code compiles cleanly or attempts are exhausted.
 */
@Service
public class AiGenerationService {

    private static final int MAX_ATTEMPTS = 3;
    private static final String OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

    @Value("${openrouter.api.key:}")
    private String apiKey;

    @Value("${openrouter.model:qwen/qwen3-coder:free}")
    private String model;

    private final CompilerService compilerService;
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();

    public AiGenerationService(CompilerService compilerService) {
        this.compilerService = compilerService;
    }

    private static final String ARROW_GRAMMAR = """
        Arrow is a symbolic programming language. Here is the complete syntax reference:

        TYPES: int  float  double  char  string  bool  void  (and user class names)

        ASSIGNMENT: varname \u2192 expression
        VAR DECL:   type name \u2192 expression      e.g.  int x \u2192 5

        PRINT:      \u2234 expression
        INPUT:      \u2235 varname

        INCREMENT:  varname\u2191   DECREMENT: varname\u2193
        SWAP:       \u2194 a b

        IF/ELSE:
          ? (condition) : statements ;
          ?? (condition) : statements ;      (else-if)
          ! : statements ;                   (else)

        LOOP (while):
          \u27F3 (condition) : statements ;

        BREAK: \u21AF   CONTINUE: \u21B7

        SWITCH:
          @(expr) :
            # value : statements ;
            * : statements ;                 (default)
          ;

        FUNCTION:
          \u0192 returnType name(type param, ...) : statements ;
          RETURN: \u2190 expression

        CLASS:
          \u25C8 ClassName \u25B3 SuperClass :
            type fieldName
            \u0192 type method() : ... ;
          ;

        INTERFACE: \u25CE Name :  \u25C6 abstract  \u2605 override  \u2726 new
        SELF: self   SUPER: super

        BOOLEAN LITERALS: \u2713 (true)  \u2717 (false)   NULL: \u2205

        LOGIC: && || ~(not)
        COMPARISON: == != < > <= >=
        ARITHMETIC: + - * / %
        COMMENTS: // line comment    /* block */

        IMPORTANT RULES:
        - Blocks always open with : and close with ;
        - No semicolons at end of statements (only to close blocks)
        - Use \u2234 for print, not print()
        - Function calls: name(args)
        - Method calls: obj.method(args)
        - new object: \u2726 ClassName(args)

        CRITICAL SYNTAX RULES (violating these breaks the compiler):
        - NEVER use = for assignment. ALWAYS use \u2192
        - NEVER use { } for blocks. ALWAYS use : to open, ; to close
        - NEVER write "print(...)" \u2014 use \u2234 followed directly by the expression
        - Every variable must be declared with a type before first use: type name \u2192 value
        - Do not invent new symbols. Only use symbols listed above.
        - Output raw Arrow code only. No markdown, no backticks, no explanation text.
        """;

    public AiGenerateResponse generate(String userPrompt) {
        AiGenerateResponse resp = new AiGenerateResponse();

        if (apiKey == null || apiKey.isBlank()) {
            resp.success = false;
            resp.attempts = 0;
            resp.message = "OPENROUTER_API_KEY is not configured on the server.";
            resp.code = "";
            return resp;
        }

        String code = "";
        String lastErrors = null;

        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            String userContent = buildPrompt(userPrompt, attempt > 1 ? code : null, attempt > 1 ? lastErrors : null);
            String raw;
            try {
                raw = callOpenRouter(userContent);
            } catch (Exception e) {
                resp.success = false;
                resp.attempts = attempt;
                resp.message = "AI request failed: " + e.getMessage();
                resp.code = code;
                return resp;
            }
            code = cleanAiCode(raw);

            CompilerService.CompileResult cr = compilerService.compile(code);
            if (!cr.diag.hasErrors()) {
                resp.success = true;
                resp.attempts = attempt;
                resp.code = code;
                resp.message = attempt == 1
                    ? "Generated and verified — compiles cleanly."
                    : "Fixed after " + attempt + " attempt(s) — compiles cleanly.";
                return resp;
            }

            lastErrors = renderErrorsForPrompt(cr.diag);

            if (attempt == MAX_ATTEMPTS) {
                resp.success = false;
                resp.attempts = attempt;
                resp.code = code;
                resp.message = "Still has " + cr.diag.errorCount() + " error(s) after " + MAX_ATTEMPTS + " attempts — showing best effort.";
                resp.remainingErrors = cr.diag.render();
            }
        }

        return resp;
    }

    private String renderErrorsForPrompt(com.arrow.diagnostic.DiagnosticBag diag) {
        StringBuilder sb = new StringBuilder();
        for (com.arrow.diagnostic.Diagnostic d : diag.sorted()) {
            sb.append("Line ").append(d.line).append(": ").append(d.message).append("\n");
        }
        return sb.toString();
    }

    private String buildPrompt(String task, String prevCode, String errorMsgs) {
        StringBuilder sb = new StringBuilder();
        sb.append(ARROW_GRAMMAR).append("\n\nTask: ").append(task);
        if (prevCode != null && errorMsgs != null) {
            sb.append("\n\nYou previously generated this Arrow code:\n").append(prevCode)
              .append("\n\nIt failed compilation with these errors:\n").append(errorMsgs)
              .append("\n\nFix the code so it compiles with no errors. Output only the corrected Arrow code.");
        }
        return sb.toString();
    }

    private String cleanAiCode(String raw) {
        if (raw == null) return "";
        return raw.replaceAll("```[a-zA-Z]*", "").replace("```", "").trim();
    }

    private String callOpenRouter(String userContent) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        List<Map<String, String>> messages = new ArrayList<>();
        messages.add(Map.of(
            "role", "system",
            "content", "You are an Arrow programming language expert. Output ONLY valid Arrow code. No explanation, no markdown, no backticks. No triple backticks ever."
        ));
        messages.add(Map.of("role", "user", "content", userContent));

        Map<String, Object> body = Map.of(
            "model", model,
            "messages", messages
        );

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        ResponseEntity<String> response;
        try {
            response = restTemplate.exchange(OPENROUTER_URL, HttpMethod.POST, entity, String.class);
        } catch (org.springframework.web.client.HttpClientErrorException e) {
            throw new RuntimeException("OpenRouter API error " + e.getStatusCode() + ": " + e.getResponseBodyAsString());
        }

        JsonNode root = mapper.readTree(response.getBody());
        JsonNode choices = root.path("choices");
        if (!choices.isArray() || choices.isEmpty()) {
            throw new RuntimeException("OpenRouter returned no choices: " + response.getBody());
        }
        return choices.get(0).path("message").path("content").asText("");
    }
}
