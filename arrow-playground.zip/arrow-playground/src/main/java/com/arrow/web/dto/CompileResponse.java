package com.arrow.web.dto;

import java.util.List;

public class CompileResponse {
    public boolean success;
    public String javaCode;   // null if compilation failed before codegen
    public String astText;    // textual AST tree, null if parse failed fatally
    public List<DiagnosticDto> diagnostics;
    public int errorCount;
    public int warningCount;

    public CompileResponse() {}
}
