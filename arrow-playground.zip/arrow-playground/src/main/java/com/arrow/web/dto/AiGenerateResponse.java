package com.arrow.web.dto;

public class AiGenerateResponse {
    public boolean success;      // true if the final code compiles with no errors
    public String code;          // final Arrow code (cleaned of markdown)
    public int attempts;         // how many attempts were made
    public String message;       // status message for the UI
    public String remainingErrors; // rendered errors if still failing after max attempts

    public AiGenerateResponse() {}
}
