package com.arrow.web;

import com.arrow.codegen.JavaGenerator;
import com.arrow.diagnostic.DiagnosticBag;
import com.arrow.lexer.Lexer;
import com.arrow.lexer.Token;
import com.arrow.parser.ASTNode;
import com.arrow.parser.ParseTree;
import com.arrow.parser.Parser;
import com.arrow.semantic.SemanticAnalyzer;
import com.arrow.simulator.ArrowSimulator;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Runs the full Arrow pipeline: Lexer -> Parser -> SemanticAnalyzer -> JavaGenerator -> (optionally) ArrowSimulator.
 * Never throws — all failures are captured in the DiagnosticBag or the CompileResult.
 */
@Service
public class CompilerService {

    public static final class CompileResult {
        public final DiagnosticBag diag;
        public final ASTNode.Program ast;   // may be null on fatal lex/parse crash
        public final String javaCode;       // null if compilation failed or codegen not reached
        public final String astText;

        CompileResult(DiagnosticBag diag, ASTNode.Program ast, String javaCode, String astText) {
            this.diag = diag; this.ast = ast; this.javaCode = javaCode; this.astText = astText;
        }

        public boolean success() { return javaCode != null && !diag.hasErrors(); }
    }

    public static final class RunResult {
        public final CompileResult compile;
        public final ArrowSimulator.Result sim; // may be null if compile failed

        RunResult(CompileResult compile, ArrowSimulator.Result sim) {
            this.compile = compile; this.sim = sim;
        }
    }

    /** Runs Lexer -> Parser -> Semantic -> CodeGen. Stops early if a phase produces errors. */
    public CompileResult compile(String source) {
        DiagnosticBag diag = new DiagnosticBag(source);

        List<Token> tokens;
        try {
            tokens = new Lexer(source, diag).tokenize();
        } catch (Exception e) {
            diag.error(0, 0, "Lexer", "fatal lexer crash: " + e.getMessage(), null);
            return new CompileResult(diag, null, null, null);
        }

        ASTNode.Program ast;
        try {
            ast = new Parser(tokens, diag).parse();
        } catch (Exception e) {
            diag.error(0, 0, "Parser", "fatal parser crash: " + e.getMessage(), null);
            return new CompileResult(diag, null, null, null);
        }

        String astText;
        try {
            astText = ParseTree.render(ast);
        } catch (Exception e) {
            astText = null;
        }

        try {
            new SemanticAnalyzer(diag).analyze(ast);
        } catch (Exception e) {
            diag.error(0, 0, "Semantic", "fatal semantic crash: " + e.getMessage(), null);
            return new CompileResult(diag, ast, null, astText);
        }

        if (diag.hasErrors()) {
            return new CompileResult(diag, ast, null, astText);
        }

        String javaCode;
        try {
            javaCode = new JavaGenerator(diag).generate(ast, source);
        } catch (Exception e) {
            diag.error(0, 0, "CodeGen", "fatal codegen crash: " + e.getMessage(), null);
            return new CompileResult(diag, ast, null, astText);
        }

        return new CompileResult(diag, ast, javaCode, astText);
    }

    /** Compiles, and if successful, simulates the program directly on the AST. */
    public RunResult run(String source) {
        CompileResult cr = compile(source);
        if (!cr.success() || cr.ast == null) {
            return new RunResult(cr, null);
        }
        ArrowSimulator.Result simResult;
        try {
            simResult = new ArrowSimulator().run(cr.ast);
        } catch (Exception e) {
            simResult = new ArrowSimulator.Result("", e.getMessage());
        }
        return new RunResult(cr, simResult);
    }
}
