package com.arrow.web.dto;

public class AiGenerateRequest {
    public String prompt;

    public AiGenerateRequest() {}
}
