package com.arrow.simulator;

import java.util.LinkedHashMap;
import java.util.Map;

/** Runtime representation of an instantiated Arrow class (`new` object). */
final class ArrowObject {
    final String className;
    final Map<String, Object> fields = new LinkedHashMap<>();

    ArrowObject(String className) { this.className = className; }

    @Override
    public String toString() { return "[" + className + " object]"; }
}
