package com.arrow.simulator;

import com.arrow.parser.ASTNode;
import com.arrow.parser.ASTNode.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Directly interprets the Arrow AST to produce program output, without needing
 * a real javac/JVM round-trip. Supports classes, inheritance, method calls,
 * self/field access, recursion, loops, switch (including boolean desugaring
 * is unnecessary here since we evaluate booleans directly), and break/continue.
 */
public final class ArrowSimulator {

    // ── Control-flow signals ────────────────────────────────────────────
    private static final class ReturnSignal extends RuntimeException {
        final Object value;
        ReturnSignal(Object v) { super(null, null, false, false); value = v; }
    }
    private static final class BreakSignal extends RuntimeException {
        BreakSignal() { super(null, null, false, false); }
    }
    private static final class ContinueSignal extends RuntimeException {
        ContinueSignal() { super(null, null, false, false); }
    }

    public static final class Result {
        public final String output;
        public final String error; // nullable
        public Result(String output, String error) { this.output = output; this.error = error; }
    }

    private final List<String> outputLines = new ArrayList<>();
    private final Map<String, ClassDecl> classes = new HashMap<>();
    private final Map<String, FuncDecl>  funcs   = new HashMap<>();
    private int steps = 0;
    private static final int MAX_STEPS = 200_000;
    private static final int MAX_LOOP_ITERS = 200_000;

    public Result run(Program ast) {
        try {
            for (ASTNode s : ast.statements) {
                if (s == null) continue;
                if (s instanceof ClassDecl)  classes.put(((ClassDecl) s).name, (ClassDecl) s);
                if (s instanceof FuncDecl)   funcs.put(((FuncDecl) s).name, (FuncDecl) s);
            }
            Env env = new Env(null);
            List<ASTNode> topLevel = new ArrayList<>();
            for (ASTNode s : ast.statements) {
                if (s == null) continue;
                if (!(s instanceof ClassDecl) && !(s instanceof FuncDecl)) topLevel.add(s);
            }
            runStmts(topLevel, env);
            return new Result(String.join("\n", outputLines), null);
        } catch (ReturnSignal rs) {
            return new Result(String.join("\n", outputLines), null);
        } catch (BreakSignal | ContinueSignal bs) {
            return new Result(String.join("\n", outputLines), "break/continue used outside a loop");
        } catch (StackOverflowError soe) {
            return new Result(String.join("\n", outputLines), "stack overflow — check for unbounded recursion");
        } catch (Exception e) {
            return new Result(String.join("\n", outputLines), e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }

    private void step() {
        if (++steps > MAX_STEPS) throw new RuntimeException("Execution limit reached (possible infinite loop)");
    }

    // ── Statement execution ──────────────────────────────────────────────

    private void runStmts(List<ASTNode> stmts, Env env) {
        for (ASTNode s : stmts) if (s != null) runStmt(s, env);
    }

    private void runBlock(Block block, Env parentEnv) {
        if (block == null) return;
        Env env = new Env(parentEnv);
        runStmts(block.statements, env);
    }

    @SuppressWarnings("unchecked")
    private void runStmt(ASTNode s, Env env) {
        step();
        if (s instanceof FuncDecl)  { funcs.put(((FuncDecl) s).name, (FuncDecl) s); return; }
        if (s instanceof ClassDecl) { classes.put(((ClassDecl) s).name, (ClassDecl) s); return; }

        if (s instanceof VarDecl) {
            VarDecl v = (VarDecl) s;
            Object val = v.init != null ? eval(v.init, env) : zero(v.type);
            env.set(v.name, val);
            return;
        }
        if (s instanceof Assign) {
            Assign a = (Assign) s;
            env.set(a.name, eval(a.value, env));
            return;
        }
        if (s instanceof MemberAssign) {
            MemberAssign ma = (MemberAssign) s;
            Object target = eval(ma.target, env);
            if (target == null && ma.target instanceof Self) target = env.get("__self");
            if (target instanceof ArrowObject) {
                Object val = eval(ma.value, env);
                ((ArrowObject) target).fields.put(ma.field, val);
                env.vars.put(ma.field, val); // keep local copy in sync (mirrors self.field usage)
            }
            return;
        }
        if (s instanceof Increment) {
            Increment inc = (Increment) s;
            env.set(inc.name, toNum(env.get(inc.name)) + 1);
            return;
        }
        if (s instanceof Decrement) {
            Decrement dec = (Decrement) s;
            env.set(dec.name, toNum(env.get(dec.name)) - 1);
            return;
        }
        if (s instanceof Swap) {
            Swap sw = (Swap) s;
            Object a = env.get(sw.a), b = env.get(sw.b);
            env.set(sw.a, b); env.set(sw.b, a);
            return;
        }
        if (s instanceof Print) {
            Object v = eval(((Print) s).expr, env);
            outputLines.add(str(v));
            return;
        }
        if (s instanceof Input) {
            // No live stdin in a web sandbox — read as empty and coerce to a safe default.
            env.set(((Input) s).name, "");
            return;
        }
        if (s instanceof Return) {
            Return r = (Return) s;
            throw new ReturnSignal(r.value != null ? eval(r.value, env) : null);
        }
        if (s instanceof Break) throw new BreakSignal();
        if (s instanceof Continue) throw new ContinueSignal();

        if (s instanceof If) {
            If f = (If) s;
            if (truthy(eval(f.cond, env))) {
                runBlock(f.thenB, env);
            } else {
                boolean taken = false;
                for (ElseIf ei : f.elseIfs) {
                    if (truthy(eval(ei.cond, env))) { runBlock(ei.body, env); taken = true; break; }
                }
                if (!taken && f.elseB != null) runBlock(f.elseB, env);
            }
            return;
        }
        if (s instanceof Loop) {
            Loop lp = (Loop) s;
            int iters = 0;
            while (truthy(eval(lp.cond, env))) {
                step();
                if (++iters > MAX_LOOP_ITERS) throw new RuntimeException("Infinite loop detected");
                try {
                    runBlock(lp.body, env);
                } catch (BreakSignal bs) {
                    break;
                } catch (ContinueSignal cs) {
                    // continue to next iteration
                }
            }
            return;
        }
        if (s instanceof Switch) {
            Switch sw = (Switch) s;
            Object v = eval(sw.expr, env);
            boolean matched = false;
            for (Case c : sw.cases) {
                if (equalsLoose(eval(c.value, env), v)) {
                    try { runBlock(c.body, env); } catch (BreakSignal bs) { /* fallthrough guard */ }
                    matched = true;
                    break;
                }
            }
            if (!matched && sw.defaultBody != null) {
                try { runBlock(sw.defaultBody, env); } catch (BreakSignal bs) { /* ok */ }
            }
            return;
        }
        if (s instanceof Block) { runBlock((Block) s, env); return; }
        if (s instanceof ExprStat) {
            ExprStat es = (ExprStat) s;
            if (es.expr != null) eval(es.expr, env);
            return;
        }
    }

    // ── Expression evaluation ─────────────────────────────────────────────

    private Object eval(ASTNode n, Env env) {
        if (n == null) return null;

        if (n instanceof IntLit)    return ((IntLit) n).value;
        if (n instanceof FloatLit)  return ((FloatLit) n).value;
        if (n instanceof BoolLit)   return ((BoolLit) n).value;
        if (n instanceof NullLit)   return null;
        if (n instanceof StringLit) return unescapeArrowString(((StringLit) n).value);
        if (n instanceof CharLit)   return ((CharLit) n).value;

        if (n instanceof Identifier) return env.get(((Identifier) n).name);
        if (n instanceof Self)       return env.get("__self");

        if (n instanceof Binary) {
            Binary b = (Binary) n;
            if ("&&".equals(b.op)) return truthy(eval(b.left, env)) && truthy(eval(b.right, env));
            if ("||".equals(b.op)) return truthy(eval(b.left, env)) || truthy(eval(b.right, env));
            Object l = eval(b.left, env), r = eval(b.right, env);
            switch (b.op) {
                case "+":
                    if (l instanceof String || r instanceof String) return str(l) + str(r);
                    return arith(l, r, '+');
                case "-": return arith(l, r, '-');
                case "*": return arith(l, r, '*');
                case "/": return arith(l, r, '/');
                case "%": return arith(l, r, '%');
                case ">":  return toNum(l) >  toNum(r);
                case "<":  return toNum(l) <  toNum(r);
                case ">=": return toNum(l) >= toNum(r);
                case "<=": return toNum(l) <= toNum(r);
                case "==": return equalsLoose(l, r);
                case "!=": return !equalsLoose(l, r);
                default: return 0;
            }
        }
        if (n instanceof Unary) {
            Unary u = (Unary) n;
            Object v = eval(u.operand, env);
            if ("-".equals(u.op)) return -toNum(v);
            return !truthy(v);
        }

        if (n instanceof Call) {
            Call c = (Call) n;
            FuncDecl fn = funcs.get(c.name);
            if (fn == null) return 0;
            List<Object> args = new ArrayList<>();
            for (ASTNode a : c.args) args.add(eval(a, env));
            Object self = env.get("__self");
            return callFunc(fn, args, self instanceof ArrowObject ? (ArrowObject) self : null);
        }

        if (n instanceof MethodCall) {
            MethodCall mc = (MethodCall) n;
            Object target = eval(mc.target, env);
            List<Object> args = new ArrayList<>();
            for (ASTNode a : mc.args) args.add(eval(a, env));
            if (target instanceof ArrowObject) {
                return callMethod((ArrowObject) target, mc.method, args);
            }
            if (target instanceof String) {
                String s = (String) target;
                switch (mc.method) {
                    case "length": return s.length();
                    case "toUpperCase": return s.toUpperCase();
                    case "toLowerCase": return s.toLowerCase();
                }
            }
            return null;
        }

        if (n instanceof MemberAccess) {
            MemberAccess ma = (MemberAccess) n;
            Object obj = eval(ma.target, env);
            if (obj instanceof ArrowObject) return ((ArrowObject) obj).fields.get(ma.field);
            return null;
        }

        if (n instanceof NewObject) {
            NewObject no = (NewObject) n;
            List<Object> args = new ArrayList<>();
            for (ASTNode a : no.args) args.add(eval(a, env));
            return newObject(no.className, args);
        }

        if (n instanceof Super) return env.get("__self");

        return null;
    }

    // ── Function / method invocation ─────────────────────────────────────

    private Object callFunc(FuncDecl fn, List<Object> args, ArrowObject selfObj) {
        Env env = new Env(null);
        if (selfObj != null) {
            env.vars.put("__self", selfObj);
            for (Map.Entry<String, Object> e : selfObj.fields.entrySet()) env.vars.put(e.getKey(), e.getValue());
        }
        for (int i = 0; i < fn.params.size(); i++) {
            Param p = fn.params.get(i);
            Object val = i < args.size() ? args.get(i) : zero(p.type);
            env.vars.put(p.name, val);
        }
        Object result = null;
        try {
            if (fn.body != null) runStmts(fn.body.statements, env);
        } catch (ReturnSignal rs) {
            result = rs.value;
        }
        if (selfObj != null) {
            for (String k : new ArrayList<>(selfObj.fields.keySet())) {
                if (env.hasLocal(k)) selfObj.fields.put(k, env.vars.get(k));
            }
        }
        return result;
    }

    private Object callMethod(ArrowObject obj, String methodName, List<Object> args) {
        ClassDecl cls = classes.get(obj.className);
        while (cls != null) {
            for (ASTNode m : cls.members) {
                if (m instanceof FuncDecl && ((FuncDecl) m).name.equals(methodName)) {
                    return callFunc((FuncDecl) m, args, obj);
                }
            }
            cls = cls.superClass != null ? classes.get(cls.superClass) : null;
        }
        return null;
    }

    private ArrowObject newObject(String className, List<Object> args) {
        ClassDecl cls = classes.get(className);
        if (cls == null) return null;

        ArrowObject obj = new ArrowObject(className);
        List<ClassDecl> chain = new ArrayList<>();
        ClassDecl c = cls;
        while (c != null) { chain.add(0, c); c = c.superClass != null ? classes.get(c.superClass) : null; }
        for (ClassDecl klass : chain) {
            for (ASTNode m : klass.members) {
                if (m instanceof VarDecl) {
                    VarDecl f = (VarDecl) m;
                    obj.fields.put(f.name, f.init != null ? evalStatic(f.init) : zero(f.type));
                }
            }
        }
        return obj;
    }

    private Object evalStatic(ASTNode n) {
        if (n instanceof IntLit)    return ((IntLit) n).value;
        if (n instanceof FloatLit)  return ((FloatLit) n).value;
        if (n instanceof BoolLit)   return ((BoolLit) n).value;
        if (n instanceof StringLit) return unescapeArrowString(((StringLit) n).value);
        return null;
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private Object zero(String type) {
        if ("string".equals(type)) return "";
        if ("bool".equals(type))   return false;
        if ("float".equals(type) || "double".equals(type)) return 0.0;
        return 0;
    }

    private boolean truthy(Object v) {
        if (v == null) return false;
        if (v instanceof Boolean) return (Boolean) v;
        if (v instanceof Number)  return ((Number) v).doubleValue() != 0;
        if (v instanceof String)  return !((String) v).isEmpty();
        return true;
    }

    private double toNum(Object v) {
        if (v == null) return 0;
        if (v instanceof Number) return ((Number) v).doubleValue();
        if (v instanceof Character) return (Character) v;
        if (v instanceof Boolean) return ((Boolean) v) ? 1 : 0;
        try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0; }
    }

    private boolean isIntLike(Object v) {
        return v instanceof Integer || (v instanceof Double && ((Double) v) == Math.floor((Double) v) && !((Double) v).isInfinite());
    }

    private Object arith(Object l, Object r, char op) {
        boolean bothInt = (l instanceof Integer) && (r instanceof Integer);
        if (bothInt) {
            int a = (Integer) l, b = (Integer) r;
            switch (op) {
                case '+': return a + b;
                case '-': return a - b;
                case '*': return a * b;
                case '/': return b == 0 ? 0 : a / b;
                case '%': return b == 0 ? 0 : a % b;
            }
        }
        double a = toNum(l), b = toNum(r);
        switch (op) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/': return b == 0 ? 0.0 : a / b;
            case '%': return b == 0 ? 0.0 : a % b;
        }
        return 0;
    }

    private boolean equalsLoose(Object a, Object b) {
        if (a == null || b == null) return a == b;
        if (a instanceof Number && b instanceof Number) {
            return ((Number) a).doubleValue() == ((Number) b).doubleValue();
        }
        return a.equals(b);
    }

    private String unescapeArrowString(String s) {
        return s.replace("\\n", "\n").replace("\\t", "\t").replace("\\r", "\r")
                .replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private String str(Object v) {
        if (v == null) return "null";
        if (v instanceof ArrowObject) return v.toString();
        if (v instanceof Double) {
            double d = (Double) v;
            if (d == Math.floor(d) && !Double.isInfinite(d)) return String.valueOf((long) d);
            return String.valueOf(d);
        }
        return String.valueOf(v);
    }
}
