package com.arrow.simulator;

import java.util.HashMap;
import java.util.Map;

/** A simple lexically-chained variable environment used by the ArrowSimulator. */
final class Env {
    final Env parent;
    final Map<String, Object> vars = new HashMap<>();

    Env(Env parent) { this.parent = parent; }

    Object get(String name) {
        Env e = this;
        while (e != null) {
            if (e.vars.containsKey(name)) return e.vars.get(name);
            e = e.parent;
        }
        return null;
    }

    void set(String name, Object val) {
        Env e = this;
        while (e != null) {
            if (e.vars.containsKey(name)) { e.vars.put(name, val); return; }
            e = e.parent;
        }
        vars.put(name, val);
    }

    boolean has(String name) {
        Env e = this;
        while (e != null) { if (e.vars.containsKey(name)) return true; e = e.parent; }
        return false;
    }

    boolean hasLocal(String name) { return vars.containsKey(name); }
}
