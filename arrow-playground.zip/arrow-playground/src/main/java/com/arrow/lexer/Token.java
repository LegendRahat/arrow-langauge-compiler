package com.arrow.lexer;

/** An immutable lexer token carrying type, raw value, and precise source location. */
public final class Token {

    public final TokenType type;
    public final String    value;
    public final int       line;   // 1-based
    public final int       col;    // 1-based

    public Token(TokenType type, String value, int line, int col) {
        this.type  = type;
        this.value = value;
        this.line  = line;
        this.col   = col;
    }

    @Override
    public String toString() {
        return String.format("Token[%-14s '%s'  @%d:%d]", type, value, line, col);
    }
}
