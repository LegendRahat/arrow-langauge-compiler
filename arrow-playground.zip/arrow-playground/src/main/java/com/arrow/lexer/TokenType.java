package com.arrow.lexer;

/** Every token kind the Arrow lexer can produce. */
public enum TokenType {

    INT_LIT, FLOAT_LIT, STRING_LIT, CHAR_LIT,
    BOOL_TRUE, BOOL_FALSE, NULL_LIT,

    IDENTIFIER,

    TYPE_INT, TYPE_FLOAT, TYPE_DOUBLE, TYPE_CHAR, TYPE_STRING, TYPE_BOOL, TYPE_VOID,

    ASSIGN,         // →
    RETURN_OP,      // ←
    INCREMENT,      // ↑
    DECREMENT,      // ↓
    SWAP,           // ↔

    PRINT,          // ∴
    INPUT,          // ∵

    PLUS, MINUS, MULTIPLY, DIVIDE, MODULO,

    GT, LT, GTE, LTE, EQ, NEQ,

    AND, OR, NOT,

    IF,             // ?
    ELSE_IF,        // ??
    ELSE,           // !
    LOOP,           // ⟲
    BREAK,          // ↯
    CONTINUE,       // ↷

    SWITCH,         // @
    CASE,           // #
    DEFAULT,        // *

    BLOCK_START,    // :
    BLOCK_END,      // ;
    LPAREN,
    RPAREN,
    COMMA,
    DOT,

    FUNCTION,       // ƒ
    CLASS,          // ◈
    INTERFACE,      // ◎
    ABSTRACT,       // ◆
    OVERRIDE,       // ★
    EXTENDS,        // △
    IMPLEMENTS,
    NEW,            // ✦
    SELF,
    SUPER,

    EOF
}
