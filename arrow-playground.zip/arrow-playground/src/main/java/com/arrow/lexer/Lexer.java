package com.arrow.lexer;

import com.arrow.diagnostic.DiagnosticBag;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Arrow language lexer — production-grade implementation.
 *
 * Key properties:
 *  1. Column tracking (1-based) on every token and every diagnostic.
 *  2. Error recovery: unknown characters are reported to the DiagnosticBag and
 *     skipped; the lexer never throws for a recoverable error.
 *  3. tokenize() never throws.
 *  4. Proper escape-sequence handling in string and char literals.
 *  5. Unterminated string/char literals are recovered from.
 *  6. Numeric literals are validated and bounds-checked at lex time.
 */
public final class Lexer {

    private final String        src;
    private int                 pos  = 0;
    private int                 line = 1;
    private int                 col  = 1;

    private final List<Token>       tokens = new ArrayList<>();
    private final DiagnosticBag     diag;

    private static final Map<String, TokenType> KEYWORDS = new HashMap<>();
    static {
        KEYWORDS.put("int",    TokenType.TYPE_INT);
        KEYWORDS.put("float",  TokenType.TYPE_FLOAT);
        KEYWORDS.put("double", TokenType.TYPE_DOUBLE);
        KEYWORDS.put("char",   TokenType.TYPE_CHAR);
        KEYWORDS.put("string", TokenType.TYPE_STRING);
        KEYWORDS.put("bool",   TokenType.TYPE_BOOL);
        KEYWORDS.put("void",   TokenType.TYPE_VOID);
        KEYWORDS.put("self",   TokenType.SELF);
        KEYWORDS.put("super",  TokenType.SUPER);
    }

    public Lexer(String src, DiagnosticBag diag) {
        this.src  = src != null ? src : "";
        this.diag = diag;
    }

    public List<Token> tokenize() {
        while (pos < src.length()) {
            skipWhitespaceAndComments();
            if (pos >= src.length()) break;

            char c = peek();
            if (isWordStart(c))           readWord();
            else if (isDigit(c))          readNumber();
            else if (c == '"')            readString();
            else if (c == '\'')           readChar();
            else                          readSymbol();
        }
        emitAt(TokenType.EOF, "EOF", line, col);
        return tokens;
    }

    private boolean isWordStart(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
    }
    private boolean isWordPart(char c) { return isWordStart(c) || isDigit(c); }
    private boolean isDigit(char c) { return c >= '0' && c <= '9'; }

    private char peek() { return pos < src.length() ? src.charAt(pos) : '\0'; }
    private char peekNext() { return (pos + 1) < src.length() ? src.charAt(pos + 1) : '\0'; }

    private char advance() {
        if (pos >= src.length()) return '\0';
        char c = src.charAt(pos++);
        if (c == '\n') { line++; col = 1; } else { col++; }
        return c;
    }

    private void emitAt(TokenType type, String value, int tokenLine, int tokenCol) {
        tokens.add(new Token(type, value, tokenLine, tokenCol));
    }

    private void skipWhitespaceAndComments() {
        while (pos < src.length()) {
            char c = peek();
            if (c == ' ' || c == '\t' || c == '\r') advance();
            else if (c == '\n') advance();
            else if (c == '/' && peekNext() == '/') { while (pos < src.length() && peek() != '\n') advance(); }
            else if (c == '/' && peekNext() == '*') skipBlockComment();
            else break;
        }
    }

    private void skipBlockComment() {
        int startLine = line, startCol = col;
        advance(); advance();
        while (pos < src.length()) {
            if (peek() == '*' && peekNext() == '/') { advance(); advance(); return; }
            advance();
        }
        diag.error(startLine, startCol, "Lexer", "unterminated block comment (opened here)",
                   "close the comment with '*/'", null);
    }

    private void readWord() {
        int tokLine = line, tokCol = col;
        int start = pos;
        while (pos < src.length() && isWordPart(peek())) advance();
        String word = src.substring(start, pos);
        emitAt(KEYWORDS.getOrDefault(word, TokenType.IDENTIFIER), word, tokLine, tokCol);
    }

    private void readNumber() {
        int tokLine = line, tokCol = col;
        int start   = pos;
        boolean isFloat = false;
        boolean malformedExponent = false;

        while (pos < src.length() && isDigit(peek())) advance();

        if (pos < src.length() && peek() == '.' && isDigit(peekNext())) {
            isFloat = true;
            advance();
            while (pos < src.length() && isDigit(peek())) advance();
        }

        if (pos < src.length() && (peek() == 'e' || peek() == 'E')) {
            char next = peekNext();
            if (isDigit(next) || next == '+' || next == '-') {
                isFloat = true;
                advance();
                if (peek() == '+' || peek() == '-') advance();
                if (!isDigit(peek())) {
                    diag.error(line, col, "Lexer",
                               "malformed numeric literal: expected digits after exponent",
                               "add at least one digit, e.g. '5e1', or remove the exponent", null);
                    malformedExponent = true;
                } else {
                    while (pos < src.length() && isDigit(peek())) advance();
                }
            }
        }

        String text = src.substring(start, pos);

        if (malformedExponent) {
            emitAt(TokenType.FLOAT_LIT, "0.0", tokLine, tokCol);
            return;
        }

        if (!isFloat) {
            try {
                long asLong = Long.parseLong(text);
                if (asLong > Integer.MAX_VALUE || asLong < Integer.MIN_VALUE) {
                    diag.error(tokLine, tokCol, "Lexer",
                               "integer literal '" + text + "' is out of range for a 32-bit int",
                               "Arrow integers are 32-bit; use a smaller value or 'double' arithmetic",
                               null);
                    long clamped = asLong > Integer.MAX_VALUE ? Integer.MAX_VALUE : Integer.MIN_VALUE;
                    emitAt(TokenType.INT_LIT, String.valueOf(clamped), tokLine, tokCol);
                    return;
                }
            } catch (NumberFormatException e) {
                diag.error(tokLine, tokCol, "Lexer",
                           "integer literal '" + text + "' is too large to represent",
                           "Arrow integers are 32-bit; use a smaller value", null);
                emitAt(TokenType.INT_LIT, String.valueOf(Integer.MAX_VALUE), tokLine, tokCol);
                return;
            }
        }

        emitAt(isFloat ? TokenType.FLOAT_LIT : TokenType.INT_LIT, text, tokLine, tokCol);
    }

    private void readString() {
        int tokLine = line, tokCol = col;
        advance();
        StringBuilder sb = new StringBuilder();
        boolean closed = false;

        while (pos < src.length()) {
            char c = peek();
            if (c == '"') { advance(); closed = true; break; }
            if (c == '\n') {
                diag.error(tokLine, tokCol, "Lexer", "unterminated string literal",
                           "string literals cannot span multiple lines; close with '\"'", null);
                break;
            }
            if (c == '\\') {
                advance();
                if (pos >= src.length()) break;
                char esc = advance();
                switch (esc) {
                    case 'n':  sb.append("\\n");  break;
                    case 't':  sb.append("\\t");  break;
                    case 'r':  sb.append("\\r");  break;
                    case '"':  sb.append("\\\""); break;
                    case '\'': sb.append("\\'");  break;
                    case '\\': sb.append("\\\\"); break;
                    case '0':  sb.append("\\0");  break;
                    default:
                        diag.warning(line, col - 1, "Lexer",
                                     "unknown escape sequence '\\" + esc + "' in string",
                                     "valid escapes: \\n \\t \\r \\\\ \\\" \\' \\0", null);
                        sb.append('\\').append(esc);
                }
            } else {
                sb.append(advance());
            }
        }

        if (!closed && pos >= src.length()) {
            diag.error(tokLine, tokCol, "Lexer",
                       "unterminated string literal (reached end of file)",
                       "close the string with '\"'", null);
        }

        emitAt(TokenType.STRING_LIT, sb.toString(), tokLine, tokCol);
    }

    private void readChar() {
        int tokLine = line, tokCol = col;
        advance();

        char value;

        if (pos >= src.length() || peek() == '\n') {
            diag.error(tokLine, tokCol, "Lexer", "empty or unterminated char literal",
                       "char literals must contain exactly one character, e.g. 'a'", null);
            emitAt(TokenType.CHAR_LIT, "\0", tokLine, tokCol);
            return;
        }

        if (peek() == '\\') {
            advance();
            if (pos >= src.length()) {
                diag.error(tokLine, tokCol, "Lexer", "unterminated char escape sequence", null, null);
                emitAt(TokenType.CHAR_LIT, "\0", tokLine, tokCol);
                return;
            }
            char esc = advance();
            switch (esc) {
                case 'n':  value = '\n'; break;
                case 't':  value = '\t'; break;
                case 'r':  value = '\r'; break;
                case '\\': value = '\\'; break;
                case '\'': value = '\''; break;
                case '0':  value = '\0'; break;
                default:
                    diag.warning(line, col - 1, "Lexer",
                                 "unknown char escape '\\" + esc + "'",
                                 "valid escapes: \\n \\t \\r \\\\ \\' \\0", null);
                    value = esc;
            }
        } else {
            value = advance();
        }

        if (pos >= src.length() || peek() != '\'') {
            diag.error(tokLine, tokCol, "Lexer",
                       "char literal must contain exactly one character",
                       "use a string \"...\" for multi-character sequences", null);
            while (pos < src.length() && peek() != '\'' && peek() != '\n') advance();
            if (pos < src.length() && peek() == '\'') advance();
        } else {
            advance();
        }

        emitAt(TokenType.CHAR_LIT, String.valueOf(value), tokLine, tokCol);
    }

    private void readSymbol() {
        int tokLine = line, tokCol = col;
        char c = peek();

        switch (c) {
            case '\u2192': advance(); emitAt(TokenType.ASSIGN,     "\u2192", tokLine, tokCol); return;
            case '\u2190': advance(); emitAt(TokenType.RETURN_OP,  "\u2190", tokLine, tokCol); return;
            case '\u2191': advance(); emitAt(TokenType.INCREMENT,  "\u2191", tokLine, tokCol); return;
            case '\u2193': advance(); emitAt(TokenType.DECREMENT,  "\u2193", tokLine, tokCol); return;
            case '\u2194': advance(); emitAt(TokenType.SWAP,       "\u2194", tokLine, tokCol); return;

            case '\u2234': advance(); emitAt(TokenType.PRINT, "\u2234", tokLine, tokCol); return;
            case '\u2235': advance(); emitAt(TokenType.INPUT, "\u2235", tokLine, tokCol); return;

            case '\u27F3': advance(); emitAt(TokenType.LOOP,     "\u27F3", tokLine, tokCol); return;
            case '\u27F2': advance(); emitAt(TokenType.LOOP, "\u27F3", tokLine, tokCol); return;
            case '\u21AF': advance(); emitAt(TokenType.BREAK,    "\u21AF", tokLine, tokCol); return;
            case '\u21B7': advance(); emitAt(TokenType.CONTINUE, "\u21B7", tokLine, tokCol); return;

            case '\u2713': advance(); emitAt(TokenType.BOOL_TRUE,  "\u2713", tokLine, tokCol); return;
            case '\u2717': advance(); emitAt(TokenType.BOOL_FALSE, "\u2717", tokLine, tokCol); return;

            case '\u2205': advance(); emitAt(TokenType.NULL_LIT, "\u2205", tokLine, tokCol); return;

            case '\u0192': advance(); emitAt(TokenType.FUNCTION,  "\u0192", tokLine, tokCol); return;
            case '\u25C8': advance(); emitAt(TokenType.CLASS,     "\u25C8", tokLine, tokCol); return;
            case '\u25CE': advance(); emitAt(TokenType.INTERFACE, "\u25CE", tokLine, tokCol); return;
            case '\u25C6': advance(); emitAt(TokenType.ABSTRACT,  "\u25C6", tokLine, tokCol); return;
            case '\u2605': advance(); emitAt(TokenType.OVERRIDE,  "\u2605", tokLine, tokCol); return;
            case '\u25B3': advance(); emitAt(TokenType.EXTENDS,   "\u25B3", tokLine, tokCol); return;
            case '\u2726': advance(); emitAt(TokenType.NEW,       "\u2726", tokLine, tokCol); return;

            case '(': advance(); emitAt(TokenType.LPAREN,      "(", tokLine, tokCol); return;
            case ')': advance(); emitAt(TokenType.RPAREN,      ")", tokLine, tokCol); return;
            case ':': advance(); emitAt(TokenType.BLOCK_START, ":", tokLine, tokCol); return;
            case ';': advance(); emitAt(TokenType.BLOCK_END,   ";", tokLine, tokCol); return;
            case ',': advance(); emitAt(TokenType.COMMA,       ",", tokLine, tokCol); return;
            case '.': advance(); emitAt(TokenType.DOT,         ".", tokLine, tokCol); return;
            case '+': advance(); emitAt(TokenType.PLUS,        "+", tokLine, tokCol); return;
            case '-': advance(); emitAt(TokenType.MINUS,       "-", tokLine, tokCol); return;
            case '*': advance(); emitAt(TokenType.MULTIPLY,    "*", tokLine, tokCol); return;
            case '/': advance(); emitAt(TokenType.DIVIDE,      "/", tokLine, tokCol); return;
            case '%': advance(); emitAt(TokenType.MODULO,      "%", tokLine, tokCol); return;
            case '~': advance(); emitAt(TokenType.NOT,         "~", tokLine, tokCol); return;

            case '@': advance(); emitAt(TokenType.SWITCH, "@", tokLine, tokCol); return;
            case '#': advance(); emitAt(TokenType.CASE,   "#", tokLine, tokCol); return;

            case '>':
                advance();
                if (peek() == '=') { advance(); emitAt(TokenType.GTE, ">=", tokLine, tokCol); }
                else                { emitAt(TokenType.GT,  ">",  tokLine, tokCol); }
                return;

            case '<':
                advance();
                if (peek() == '=') { advance(); emitAt(TokenType.LTE, "<=", tokLine, tokCol); }
                else                { emitAt(TokenType.LT,  "<",  tokLine, tokCol); }
                return;

            case '=':
                advance();
                if (peek() == '=') {
                    advance();
                    emitAt(TokenType.EQ, "==", tokLine, tokCol);
                } else {
                    diag.error(tokLine, tokCol, "Lexer",
                               "unexpected '=' — Arrow uses '→' (U+2192) for assignment",
                               "replace '=' with '→'", null);
                    emitAt(TokenType.ASSIGN, "→", tokLine, tokCol);
                }
                return;

            case '!':
                advance();
                if (peek() == '=') { advance(); emitAt(TokenType.NEQ,  "!=", tokLine, tokCol); }
                else                { emitAt(TokenType.ELSE, "!",  tokLine, tokCol); }
                return;

            case '?':
                advance();
                if (peek() == '?') { advance(); emitAt(TokenType.ELSE_IF, "??", tokLine, tokCol); }
                else                { emitAt(TokenType.IF,      "?",  tokLine, tokCol); }
                return;

            case '&':
                advance();
                if (peek() == '&') {
                    advance();
                    emitAt(TokenType.AND, "&&", tokLine, tokCol);
                } else {
                    diag.error(tokLine, tokCol, "Lexer",
                               "single '&' is not a valid Arrow operator",
                               "use '&&' for logical AND", null);
                    emitAt(TokenType.AND, "&&", tokLine, tokCol);
                }
                return;

            case '|':
                advance();
                if (peek() == '|') {
                    advance();
                    emitAt(TokenType.OR, "||", tokLine, tokCol);
                } else {
                    diag.error(tokLine, tokCol, "Lexer",
                               "single '|' is not a valid Arrow operator",
                               "use '||' for logical OR", null);
                    emitAt(TokenType.OR, "||", tokLine, tokCol);
                }
                return;

            default:
                advance();
                String ucp = String.format("U+%04X", (int) c);
                diag.error(tokLine, tokCol, "Lexer",
                           "unknown character '" + safeDisplay(c) + "' (" + ucp + ")",
                           suggestForUnknown(c), null);
        }
    }

    private static String safeDisplay(char c) {
        if (Character.isISOControl(c)) return String.format("\\u%04X", (int) c);
        return String.valueOf(c);
    }

    private static String suggestForUnknown(char c) {
        switch (c) {
            case '$': return "Arrow has no '$' operator; did you mean a variable name?";
            case '^': return "Arrow has no '^' operator; for XOR consider a function";
            case '[': case ']': return "Arrow does not yet support array index syntax '[]'";
            case '{': return "Arrow uses ':' to open a block, not '{'";
            case '}': return "Arrow uses ';' to close a block, not '}'";
            default:  return null;
        }
    }
}
