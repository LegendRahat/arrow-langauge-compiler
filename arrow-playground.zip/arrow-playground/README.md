# Arrow Language Playground

A full web-based IDE for the **Arrow** symbolic programming language, backed by a real
Java compiler pipeline (Lexer → Parser → SemanticAnalyzer → JavaGenerator → ArrowSimulator),
built with Spring Boot 3 / Java 21.

## Run it

Requires Java 21 and Maven.

```bash
mvn spring-boot:run
```

Then open **http://localhost:8080** in your browser.

## AI Generate (optional)

The "AI Generate" tab calls OpenRouter (model `qwen/qwen3-coder:free`) to turn a plain-English
prompt into Arrow code, compiling and self-correcting up to 3 times using real compiler
feedback before returning the final code.

Set your API key as an environment variable before starting the app:

```bash
export OPENROUTER_API_KEY=sk-or-v1-xxxxxxxxxxxxxxxx   # Linux / macOS
set OPENROUTER_API_KEY=sk-or-v1-xxxxxxxxxxxxxxxx       # Windows CMD
$env:OPENROUTER_API_KEY="sk-or-v1-xxxxxxxxxxxxxxxx"    # Windows PowerShell

mvn spring-boot:run
```

If the key isn't set, every other feature (editor, live errors, Run, AST viewer, examples,
dark/light mode) still works fully — only AI Generate will report that no key is configured.

## Project layout

```
pom.xml
src/main/java/com/arrow/
  ArrowPlaygroundApplication.java   Spring Boot entry point
  lexer/        Lexer, Token, TokenType
  parser/       ASTNode (visitor-pattern AST), Parser (panic-mode recovery), ParseTree (AST printer)
  semantic/     SemanticAnalyzer, SymbolTable (scoped, with typo suggestions)
  codegen/      JavaGenerator (Arrow -> Java source text)
  diagnostic/   Diagnostic, DiagnosticBag (rustc-style error rendering)
  simulator/    ArrowSimulator, Env, ArrowObject — interprets the AST directly (no javac needed)
  web/          CompilerService, AiGenerationService, CompileController (REST), dto/*
src/main/resources/
  application.properties
  static/index.html, style.css, script.js   — the single-page frontend
```

## REST API

- `POST /api/compile` `{ "source": "..." }`
  → `{ success, javaCode, astText, diagnostics[], errorCount, warningCount }`

- `POST /api/run` `{ "source": "..." }`
  → `{ success, output, runtimeError, diagnostics[], errorCount, warningCount }`

- `POST /api/ai-generate` `{ "prompt": "..." }`
  → `{ success, code, attempts, message, remainingErrors }`

## Frontend features

- Code editor with line numbers and live Arrow syntax highlighting
- Tabs: Generated Java / Output / Errors / AI →
- Run button — compiles and directly simulates the program, showing real output
- Example programs: Hello World, Factorial, FizzBuzz, OOP Class, Switch, Fibonacci, Even Numbers
- Live error checking, debounced 500ms, with erroneous lines highlighted in the gutter
  and clickable error cards that jump the cursor to the offending line
- Dark / light mode toggle, persisted in `localStorage`
- AST Tree modal — renders the textual parse tree for the current source
- Responsive layout for narrower viewports
